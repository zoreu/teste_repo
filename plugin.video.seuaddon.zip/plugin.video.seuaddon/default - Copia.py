try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import time
import sys
from urllib.parse import urlencode, parse_qs
import threading

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

exit_command = False
clock_stop = False

import pyxbmct.addonwindow as pyxbmct

def MainWindow():
    window = Main('sktv')
    window.doModal()
    del window

def MainWindow2():
    window = Main2('sktv')
    window.doModal()
    del window    

def killaddon(self):
    xbmc.executebuiltin("Container.Update(path,replace)")
    #xbmc.executebuiltin("ActivateWindow(Home)")
    self.close()

def play_video(url):
    """Reproduz um vídeo."""
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    

class Main(pyxbmct.AddonFullWindow):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    def __init__(self, title="Login"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.set_info_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.setFocus(self.username_input)
        # self.thread_clock = threading.Thread(target=self.clock) 
        # self.thread_clock.start()        

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        background_image_path = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/background.jpg"
        )
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.main_bg.setImage(background_image_path)
        self.addControl(self.main_bg)

    # def clock(self):
    #     while True:
    #         c = time.strftime("%I:%M %p")
    #         self.TIME.setLabel(str(c))
    #         if clock_stop:
    #             break  

    def set_info_controls(self):
        # Label para o título
        #self.title_label = pyxbmct.Label("SPARTAN:", textColor="0xFFFFFFFF", alignment=pyxbmct.ALIGN_CENTER)
        #self.placeControl(self.title_label, 2, 1, 12, 50)      

        # Campo para nome de usuário
        #self.username_label = pyxbmct.Label("Usuário:", textColor="0xFFFF0000", font='font40', alignment=pyxbmct.ALIGN_CENTER)
        #self.placeControl(self.username_label, 109, 6, 12, 10)

        self.username_input = pyxbmct.Edit('', font='font40', textColor='0xFFFFFFFF', disabledColor='0xFFFFFFFF', _alignment=0, focusTexture='0xFFFFFFFF', noFocusTexture='0xFFFFFFFF')
        self.placeControl(self.username_input, 84, 20, 15, 10)

        # Campo para senha
        #self.password_label = pyxbmct.Label("Senha:", textColor="0xFFFF0000", font='font40', alignment=pyxbmct.ALIGN_CENTER)
        #self.placeControl(self.password_label, 118, 6, 12, 10)
        self.password_input = pyxbmct.Edit('', font='font40', textColor='0xFFFFFFFF', disabledColor='0xFFFFFFFF', _alignment=0, focusTexture='0xFFFFFFFF', noFocusTexture='0xFFFFFFFF')
        self.placeControl(self.password_input, 102, 20, 15, 10)

        # Botão de Login com efeito de mouse-over
        login_button_normal = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/login_unselect.png"
        )
        login_button_hover = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/login_select.png"
        )
        self.login_button = pyxbmct.Button("", focusTexture=login_button_hover, noFocusTexture=login_button_normal)
        self.placeControl(self.login_button, 113, 15, 25, 10)
        self.connect(self.login_button, self.login_action)

        # Botão de Cancelar com efeito de mouse-over
        cancel_button_normal = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/sair_unselect.png"
        )
        cancel_button_hover = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/sair_select.png"
        )
        self.cancel_button = pyxbmct.Button("", focusTexture=cancel_button_hover, noFocusTexture=cancel_button_normal)
        self.placeControl(self.cancel_button, 113, 25, 25, 10)
        self.connect(self.cancel_button, self.close)     

        # self.TIME = pyxbmct.Label('', textColor='0xFFFFFFFF', font='font14')
        # self.placeControl(self.TIME, 150, 43, 12, 10)         
        # self.connectEventList(
        #     [pyxbmct.ACTION_MOVE_DOWN,
        #     pyxbmct.ACTION_MOVE_UP,
        #     pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
        #     pyxbmct.ACTION_MOUSE_WHEEL_UP,
        #     pyxbmct.ACTION_MOUSE_MOVE],
        #     self.clock)

        # self.TIME = pyxbmct.Label('', textColor='0xFFFFFFFF', font='font14')
        # self.placeControl(self.TIME, 64, 40, 12, 10)         
        # self.connectEventList(
        #     [pyxbmct.ACTION_MOVE_DOWN,
        #     pyxbmct.ACTION_MOVE_UP,
        #     pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
        #     pyxbmct.ACTION_MOUSE_WHEEL_UP,
        #     pyxbmct.ACTION_MOUSE_MOVE],
        #     self.clock)        

    def set_navigation(self):
        self.username_input.controlDown(self.password_input)
        self.password_input.controlUp(self.username_input)
        self.password_input.controlDown(self.login_button)
        self.login_button.controlUp(self.password_input)
        self.login_button.controlRight(self.cancel_button)
        self.cancel_button.controlLeft(self.login_button)

    def login_action(self):
        username = self.username_input.getText()
        password = self.password_input.getText()
        if username and password:
            #xbmcgui.Dialog().ok("Login bem-sucedido", f"Bem-vindo, {username}!")
            xbmcgui.Dialog().notification("Info", "Login efetuado com sucesso!", xbmcgui.NOTIFICATION_INFO)
            op = xbmcgui.Dialog().select('SELECIONE O SERVIDOR', ['SERVIDOR 1'])
            if op == 0:
                MainWindow2()
            else:
                pass
        else:
            xbmcgui.Dialog().notification("Erro", "Por favor, preencha todos os campos.", xbmcgui.NOTIFICATION_ERROR)

    def close(self):
        xbmc.executebuiltin("Container.Update(path,replace)")
        xbmc.executebuiltin("Container.Refresh()")
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ActivateWindow(Home)")
        clock_stop = True
        exit_command = True
        super().close()   


def Player(item):
    stream_url=item['url']
    liz = xbmcgui.ListItem(item['name'])
    #liz.setArt({"thumb": iconimage})
    liz.setProperty('IsPlayable', 'true')
    #liz.setInfo('video', {'Plot': desc})
    liz.setPath(stream_url)
    xbmc.Player ().play(stream_url, liz, False)
    quit()

def menu_items(self):
    global media_item
    media_item = [
        {"name": "Video 1", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", "iconimage": "https://i.scdn.co/image/dd031b9c5d1b6eba4a691cd89c954255aae787f2"}, 
        {"name": "Video 2", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", "iconimage": "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/MadonnaO2171023_%28125_of_133%29_%2853270844239%29_%28cropped%29.jpg/1200px-MadonnaO2171023_%28125_of_133%29_%2853270844239%29_%28cropped%29.jpg"} 
        ]
    for i in media_item:
        self.list.addItem('[B]%s[/B]' %i['name'] )
    



class Main2(pyxbmct.AddonFullWindow):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    def __init__(self, title="Login"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.set_list_controls()
        menu_items(self)
        self.setFocus(self.list)
        self.connect(pyxbmct.ACTION_NAV_BACK, lambda:killaddon(self))
        self.connect(self.list, lambda:Player(item))
        self.update_logo()
        

     

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        background_image_path = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/background2.jpg"
        )
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.main_bg.setImage(background_image_path)
        self.addControl(self.main_bg)

      

    def update_list(self): 
        global media_item 
        global item 
        try: 
            if self.getFocus() == self.list: 
                position = self.list.getSelectedPosition()
                item = media_item[position]
                self.Show_Logo.setImage(item['iconimage'])
        except (RuntimeError, SystemError):
            pass

    def update_logo(self): 
        """Atualiza o logo quando a lista é carregada.""" 
        if len(media_item) > 0: 
            self.Show_Logo.setImage(media_item[0]['iconimage'])                            


    def set_list_controls(self): 
        self.list = pyxbmct.List() 
        self.placeControl(self.list, 50, 10, 40, 30) 
        self.connectEventList(
			[pyxbmct.ACTION_MOVE_DOWN,
			pyxbmct.ACTION_MOVE_UP,
			pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
			pyxbmct.ACTION_MOUSE_WHEEL_UP,
			pyxbmct.ACTION_MOUSE_MOVE],
			self.update_list)
            # logo
        self.Show_Logo = pyxbmct.Image('')
        self.placeControl(self.Show_Logo, 10, 41, 60, 8)         
        # self.add_list_items() 
                           

    def back(self):
        MainWindow() 




# MODELO COM PAGINACAO FALHADA

# media_item = []
# current_page = 0
# items_per_page = 2  # Número de itens por página

# def Player(item):
#     stream_url=item['url']
#     liz = xbmcgui.ListItem(item['name'])
#     #liz.setArt({"thumb": iconimage})
#     liz.setProperty('IsPlayable', 'true')
#     #liz.setInfo('video', {'Plot': desc})
#     liz.setPath(stream_url)
#     xbmc.Player ().play(stream_url, liz, False)
#     quit()

# def load_items_from_url():
#     global media_item
#     # Simulação de carregamento de itens de uma URL
#     media_item = [
#         {"name": "Video 1", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"},
#         {"name": "Video 2", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"},
#         {"name": "Video 3", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"},
#         {"name": "Video 4", "url": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"}
#     ]

# class Main2(pyxbmct.AddonFullWindow):
#     xbmc.executebuiltin("Dialog.Close(busydialog)")

#     def __init__(self, title="Login"):
#         super().__init__(title)
#         self.setGeometry(1280, 720, 150, 50)
#         self.set_background_image()
#         self.set_list_controls()
#         self.load_page(0)
#         self.setFocus(self.list)
#         self.connect(pyxbmct.ACTION_NAV_BACK, lambda: killaddon(self))
#         self.connect(self.list, lambda:Player(item))

#     def set_background_image(self):
#         """Define uma imagem de fundo para a janela."""
#         background_image_path = xbmcvfs.translatePath(
#             "special://home/addons/plugin.video.seuaddon/resources/media/background2.jpg"
#         )
#         self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
#         self.main_bg.setImage(background_image_path)
#         self.addControl(self.main_bg)

#     def set_list_controls(self):
#         self.list = pyxbmct.List()
#         self.placeControl(self.list, 50, 10, 40, 30)
#         self.connectEventList(
#             [pyxbmct.ACTION_MOVE_DOWN,
#              pyxbmct.ACTION_MOVE_UP,
#              pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
#              pyxbmct.ACTION_MOUSE_WHEEL_UP,
#              pyxbmct.ACTION_MOUSE_MOVE],
#             self.update_list)

#         self.next_button = pyxbmct.Button("Próxima Página")
#         self.placeControl(self.next_button, 92, 35, 5, 10)
#         self.connect(self.next_button, self.next_page)

#         self.prev_button = pyxbmct.Button("Página Anterior")
#         self.placeControl(self.prev_button, 92, 5, 5, 10)
#         self.connect(self.prev_button, self.prev_page)

#     def update_list(self):
#         global media_item, item
#         try:
#             if self.getFocus() == self.list:
#                 position = self.list.getSelectedPosition()
#                 item = media_item[position]
#         except (RuntimeError, SystemError):
#             pass

#     def load_page(self, page):
#         global current_page
#         current_page = page
#         self.list.reset()

#         start_index = page * items_per_page
#         end_index = start_index + items_per_page
#         for item in media_item[start_index:end_index]:
#             self.list.addItem(item['name'])

#         self.update_list()

#     def next_page(self):
#         global current_page
#         if (current_page + 1) * items_per_page < len(media_item):
#             self.load_page(current_page + 1)

#     def prev_page(self):
#         global current_page
#         if current_page > 0:
#             self.load_page(current_page - 1)

#     def back(self):
#         MainWindow()

# load_items_from_url()

###########################################

# args = parse_qs(sys.argv[2][1:])
# action = args.get("action", [None])[0]

# if action == "play":
#     video_url = args.get("video", [None])[0]
#     if video_url:
#         play_video(video_url)
# elif action == "login":
#     MainWindow()
# else:
#     if not exit_command:
#         MainWindow()



if not exit_command:
    MainWindow()
