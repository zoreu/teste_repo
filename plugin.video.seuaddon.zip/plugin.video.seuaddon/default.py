try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import time
import sys
from urllib.parse import urlencode, parse_qs

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

exit_command = False

import pyxbmct.addonwindow as pyxbmct

def MainWindow():
    window = Main('sktv')
    window.doModal()
    del window

def killaddon(self):
    xbmc.executebuiltin("Container.Update(path,replace)")
    xbmc.executebuiltin("ActivateWindow(Home)")
    self.close()

def build_url(query):
    """Constrói URLs para itens."""
    return f"{base_url}?{urlencode(query)}"

def play_video(url):
    """Reproduz um vídeo."""
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, li)

def run():
    """Cria o menu principal."""
    xbmcplugin.setPluginCategory(addon_handle, "Menu Principal")
    xbmcplugin.setContent(addon_handle, "videos")
    
    # Adicionando itens ao menu
    items = [
        {"label": "Item 1 - Vídeo", "url": build_url({"action": "play", "video": "https://www.example.com/video.mp4"})},
        {"label": "Pagina de Login", "url": build_url({"action": "login"})},
    ]

    for item in items:
        li = xbmcgui.ListItem(label=item["label"])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=item["url"], listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)     

class Main(pyxbmct.AddonFullWindow):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    def __init__(self, title="Login"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.set_info_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.setFocus(self.login_button)

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        background_image_path = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/background.jpg"
        )
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.main_bg.setImage(background_image_path)
        self.addControl(self.main_bg)

    def clock(self):
        c = time.strftime("%I:%M %p")
        self.TIME.setLabel(str(c))    

    def set_info_controls(self):
        # Label para o título
        #self.title_label = pyxbmct.Label("SPARTAN:", textColor="0xFFFFFFFF", alignment=pyxbmct.ALIGN_CENTER)
        #self.placeControl(self.title_label, 2, 1, 12, 50)      

        # Campo para nome de usuário
        #self.username_label = pyxbmct.Label("Usuário:", textColor="0xFFFF0000", font='font40', alignment=pyxbmct.ALIGN_CENTER)
        #self.placeControl(self.username_label, 109, 6, 12, 10)

        self.username_input = pyxbmct.Edit('', font='font40', textColor='0xFFFFFFFF', disabledColor='0xFFFFFFFF', _alignment=0, focusTexture='0xFFFFFFFF', noFocusTexture='0xFFFFFFFF')
        self.placeControl(self.username_input, 84, 20, 15, 10)

        # Campo para senha
        #self.password_label = pyxbmct.Label("Senha:", textColor="0xFFFF0000", font='font40', alignment=pyxbmct.ALIGN_CENTER)
        #self.placeControl(self.password_label, 118, 6, 12, 10)
        self.password_input = pyxbmct.Edit('', font='font40', textColor='0xFFFFFFFF', disabledColor='0xFFFFFFFF', _alignment=0, focusTexture='0xFFFFFFFF', noFocusTexture='0xFFFFFFFF')
        self.placeControl(self.password_input, 102, 20, 15, 10)

        # Botão de Login com efeito de mouse-over
        login_button_normal = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/login_unselect.png"
        )
        login_button_hover = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/login_select.png"
        )
        self.login_button = pyxbmct.Button("", focusTexture=login_button_hover, noFocusTexture=login_button_normal)
        self.placeControl(self.login_button, 140, 15, 25, 10)
        self.connect(self.login_button, self.login_action)

        # Botão de Cancelar com efeito de mouse-over
        cancel_button_normal = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/sair_unselect.png"
        )
        cancel_button_hover = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/sair_select.png"
        )
        self.cancel_button = pyxbmct.Button("", focusTexture=cancel_button_hover, noFocusTexture=cancel_button_normal)
        self.placeControl(self.cancel_button, 140, 25, 25, 10)
        self.connect(self.cancel_button, self.close)

        self.TIME = pyxbmct.Label('', textColor='0xFFFFFFFF', font='font14')
        self.placeControl(self.TIME, 158, 47, 12, 10)         
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
            pyxbmct.ACTION_MOVE_UP,
            pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
            pyxbmct.ACTION_MOUSE_WHEEL_UP,
            pyxbmct.ACTION_MOUSE_MOVE],
            self.clock)

    def set_navigation(self):
        self.username_input.controlDown(self.password_input)
        self.password_input.controlUp(self.username_input)
        self.password_input.controlDown(self.login_button)
        self.login_button.controlUp(self.password_input)
        self.login_button.controlRight(self.cancel_button)
        self.cancel_button.controlLeft(self.login_button)

    def login_action(self):
        username = self.username_input.getText()
        password = self.password_input.getText()
        if username and password:
            xbmcgui.Dialog().ok("Login bem-sucedido", f"Bem-vindo, {username}!")
            self.close()
        else:
            xbmcgui.Dialog().notification("Erro", "Por favor, preencha todos os campos.", xbmcgui.NOTIFICATION_ERROR)

    def close(self):
        xbmc.executebuiltin("Container.Update(path,replace)")
        xbmc.executebuiltin("Container.Refresh()")
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ActivateWindow(Home)")
        super().close()
        exit_command = True

args = parse_qs(sys.argv[2][1:])
action = args.get("action", [None])[0]

if action == "play":
    video_url = args.get("video", [None])[0]
    if video_url:
        play_video(video_url)
elif action == "login":
    MainWindow()
else:
    if not exit_command:
        MainWindow()
