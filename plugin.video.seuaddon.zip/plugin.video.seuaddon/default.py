# START ADDON
from lib import addon
addon.spartan()