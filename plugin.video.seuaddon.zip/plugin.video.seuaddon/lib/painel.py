try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import pyxbmct.addonwindow as pyxbmct
from lib import acesso, addon, tela_jogos, speedtest, xtream, tela_iptv
import os
import six
import time
import sys
import threading




addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
homeDir = addon.getAddonInfo('path')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
addonIcon = translate(os.path.join(homeDir, 'icon.png'))

global exit_command2
exit_command2 = False
DISABLE_CLOCK = False

def tela_inicial():
    global exit_command2
    if not exit_command2:
        window = Panel('Spartan_painel')
        window.doModal()
        del window

def fechar_janela(self):
    global exit_command2
    exit_command2 = True
    xbmc.executebuiltin("Container.Update(path,replace)")
    xbmc.executebuiltin("Container.Refresh()")
    xbmc.executebuiltin("Dialog.Close(all,true)")
    xbmc.executebuiltin("ActivateWindow(Home)")
    self.close()
    sys.exit()
    

def deslogar(self):
    global exit_command2
    exit_command2 = True    
    acesso.setsetting('username', '')
    acesso.setsetting('password', '')
    xbmc.executebuiltin("Container.Update(path,replace)")
    self.close() 
    sys.exit()    

def clock(self):
    time2 = time.strftime("%I:%M %p")
    self.TIME.setLabel(str(time2))   


class Panel(pyxbmct.AddonFullWindow):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    def __init__(self, title="Painel"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.connect(pyxbmct.ACTION_NAV_BACK, lambda: fechar_janela(self))
        self.welcome()
        self.botoes_sair()
        self.set_vencimento_info()
        self.botoes_painel()
        self.setFocus(self.live_button)
        self.set_navigation()
        self.relogio()

    def update_relogio(self):
        clock(self)        

    def relogio(self):
        self.TIME = pyxbmct.Label('',textColor='0xFFFFFFFF', font='font14')
        self.placeControl(self.TIME, 1,42, 12, 10)
        time2 = time.strftime("%I:%M %p")
        self.TIME.setLabel(str(time2))
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
            pyxbmct.ACTION_MOVE_UP,
            pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
            pyxbmct.ACTION_MOUSE_WHEEL_UP,
            pyxbmct.ACTION_MOUSE_MOVE],
            self.update_relogio)        

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        background_image_path = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/background3.png"
        )
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.main_bg.setImage(background_image_path)
        self.addControl(self.main_bg)

    def welcome(self):
        addon = xbmcaddon.Addon()
        version = addon.getAddonInfo('version')
        self.addon_info = pyxbmct.Label("SPARTAN:", textColor="0xFFFFFFFF", font='font20')
        self.placeControl(self.addon_info, 0, 10, 15, 10) 
        self.addon_info = pyxbmct.Label("Versão: %s"%version, textColor="0xFFFFFFFF", font='font20')
        self.placeControl(self.addon_info, 6, 10, 15, 10)         
        username = acesso.getsetting('username')          
        self.welcome_= pyxbmct.Label("Bem vindo %s!"%username, textColor="0xFFFFFF00", font='font40')
        self.placeControl(self.welcome_, 17, 10, 15, 10)        

    def botoes_painel(self):
        tv_image1 = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/tv.jpg"
        )
        tv_image2 = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/tv2.jpg"
        )        
        self.live_button = pyxbmct.Button("", focusTexture=tv_image2, noFocusTexture=tv_image1)
        self.placeControl(self.live_button, 29, 10, 30, 8)

        filmes_image1 = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/filmes.png"
        )
        filmes_image2 = xbmcvfs.translatePath(
            "special://home/addons/plugin.video.seuaddon/resources/media/filmes2.png"
        )        
        self.filmes_button = pyxbmct.Button("", focusTexture=filmes_image2, noFocusTexture=filmes_image1)
        self.placeControl(self.filmes_button, 29, 18, 30, 8)
        self.connect(self.live_button, self.abrir_tv)

        #self.connect(self.filmes_button, self.speedtest_)

        # teste speedtest
    def speedtest_(self):
        speedtest.run_speedtest()


    def abrir_tv(self):
        op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['JOGOS AO VIVO', 'LISTAS IPTV', 'LISTAS STALKER'])
        if op == 0:
            tela_jogos.jogos_window()  # Chama a função para abrir a tela de jogos
        elif op == 1:
            iptv = xtream.parselist('https://paste.kodi.tv/ekorumaguq')
            if iptv:
                servers_list = ['SERVIDOR %s'%str(n + 1) for n, (dns,username,password) in enumerate(iptv)]
                server_iptv = xbmcgui.Dialog().select('SELECIONE UM SERVIDOR', servers_list)
                if server_iptv >= 0:
                    dns = iptv[server_iptv][0]
                    username = iptv[server_iptv][1]
                    password = iptv[server_iptv][2]
                    tela_iptv.tela_xtream(dns,username,password)

                    


    def set_navigation(self):
        self.live_button.controlRight(self.filmes_button)
        self.filmes_button.controlLeft(self.live_button)
        self.live_button.controlDown(self.voltar_button)
        self.filmes_button.controlDown(self.voltar_button)
        self.voltar_button.controlRight(self.deslogar_button)
        self.deslogar_button.controlLeft(self.voltar_button)
        self.voltar_button.controlUp(self.live_button)
        self.deslogar_button.controlUp(self.filmes_button)

    def botoes_sair(self):
        voltar_normal = translate(
            "special://home/addons/plugin.video.seuaddon/resources/media/voltar.png"
        )
        voltar_hover = translate(
            "special://home/addons/plugin.video.seuaddon/resources/media/voltar2.png"
        )
        self.voltar_button = pyxbmct.Button("", focusTexture=voltar_hover, noFocusTexture=voltar_normal)
        self.placeControl(self.voltar_button, 120, 18, 24, 7)
        self.connect(self.voltar_button, lambda: fechar_janela(self))

        deslogar_normal = translate(
            "special://home/addons/plugin.video.seuaddon/resources/media/deslogar.png"
        )
        deslogar_hover = translate(
            "special://home/addons/plugin.video.seuaddon/resources/media/deslogar2.png"
        )
        self.deslogar_button = pyxbmct.Button("", focusTexture=deslogar_hover, noFocusTexture=deslogar_normal)
        self.placeControl(self.deslogar_button, 120, 26, 24, 7)
        self.connect(self.deslogar_button, lambda: deslogar(self))                 
        

    def set_vencimento_info(self):
        vencimento = acesso.login_info()
        if vencimento:
            self.vencimento_texto = pyxbmct.Label("Vencimento: %s"%vencimento, textColor="0xFFFFFF00", font='font40', alignment=pyxbmct.ALIGN_CENTER)
            self.placeControl(self.vencimento_texto, 140, 11, 15, 28)

#tela_inicial()
