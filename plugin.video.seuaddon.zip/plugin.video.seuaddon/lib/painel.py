try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import pyxbmct.addonwindow as pyxbmct
from lib import acesso, addon, tela_jogos, tela_stalker, speedtest, xtream, xtream_stalker, tela_iptv, github, tela_torrent, tela_vod1, tela_vod2, tela_vod1_series, tela_vod2_series, tela_torrent_series, tela_vod_doramas, tela_vod_novelas
import os
import six
import time
import sys
import threading
from lib.images import background_image_path, tv_image1, tv_image2, filmes_image1, series_image1, filmes_image2, series_image2,voltar_normal, voltar_hover, deslogar_normal, deslogar_hover, speedtest1, speedtest2, doramas1, doramas2, novelas1, novelas2



global exit_command2
exit_command2 = False
DISABLE_CLOCK = False

def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string 

def input_text(heading='Put text'):
    vq = get_search_string(heading=heading, message="")        
    if ( not vq ): return False
    return vq

def tela_inicial():
    global exit_command2
    if not exit_command2:
        window = Panel('Spartan_painel')
        window.doModal()
        del window

def fechar_janela(self):
    global exit_command2
    exit_command2 = True
    xbmc.executebuiltin("Container.Update(path,replace)")
    xbmc.executebuiltin("Container.Refresh()")
    xbmc.executebuiltin("Dialog.Close(all,true)")
    xbmc.executebuiltin("ActivateWindow(Home)")
    self.close()
    try:
        sys.exit()
    except:
        pass
    

def deslogar(self):
    global exit_command2
    exit_command2 = True    
    acesso.setsetting('username', '')
    acesso.setsetting('password', '')
    xbmc.executebuiltin("Container.Update(path,replace)")
    self.close() 
    try:
        sys.exit()
    except:
        pass

def clock(self):
    time2 = time.strftime("%I:%M %p")
    self.TIME.setLabel(str(time2))   


class Panel(pyxbmct.AddonFullWindow):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    def __init__(self, title="Painel"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.connect(pyxbmct.ACTION_NAV_BACK, lambda: fechar_janela(self))
        self.welcome()
        self.botoes_sair()
        self.set_vencimento_info()
        self.botoes_painel()
        self.setFocus(self.live_button)
        self.set_navigation()
        self.relogio()

    def update_relogio(self):
        clock(self)        

    def relogio(self):
        self.TIME = pyxbmct.Label('',textColor='0xFFFFFFFF', font='font14')
        self.placeControl(self.TIME, 1,42, 12, 10)
        time2 = time.strftime("%I:%M %p")
        self.TIME.setLabel(str(time2))
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
            pyxbmct.ACTION_MOVE_UP,
            pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
            pyxbmct.ACTION_MOUSE_WHEEL_UP,
            pyxbmct.ACTION_MOUSE_MOVE],
            self.update_relogio)        

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.main_bg.setImage(background_image_path)
        self.addControl(self.main_bg)

    def welcome(self):
        addon = xbmcaddon.Addon()
        version = addon.getAddonInfo('version')
        self.addon_info = pyxbmct.Label("SPARTAN:", textColor="0xFFFFFFFF", font='font20')
        self.placeControl(self.addon_info, 0, 10, 15, 10) 
        self.addon_info = pyxbmct.Label("Versão: %s"%version, textColor="0xFFFFFFFF", font='font20')
        self.placeControl(self.addon_info, 6, 10, 15, 10)         
        username = acesso.getsetting('username')          
        self.welcome_= pyxbmct.Label("Bem vindo %s!"%username, textColor="0xFFFFFF00", font='font40')
        self.placeControl(self.welcome_, 17, 10, 15, 10)        

    def botoes_painel(self):       
        self.live_button = pyxbmct.Button("", focusTexture=tv_image2, noFocusTexture=tv_image1)
        self.placeControl(self.live_button, 29, 10, 31, 8)      
        self.filmes_button = pyxbmct.Button("", focusTexture=filmes_image2, noFocusTexture=filmes_image1)
        self.placeControl(self.filmes_button, 29, 18, 31, 8)
        self.series_button = pyxbmct.Button("", focusTexture=series_image2, noFocusTexture=series_image1)
        self.placeControl(self.series_button, 29, 26, 31, 8) 
        if six.PY3:
            self.speedtest_button = pyxbmct.Button("", focusTexture=speedtest2, noFocusTexture=speedtest1)
            self.placeControl(self.speedtest_button, 29, 34, 31, 8)                
        self.connect(self.live_button, self.abrir_tv)
        self.connect(self.filmes_button, self.abrir_filmes)
        self.connect(self.series_button, self.abrir_series)
        if six.PY3:
            self.connect(self.speedtest_button, self.speedtest_)
        self.doramas_button = pyxbmct.Button("", focusTexture=doramas2, noFocusTexture=doramas1)
        self.placeControl(self.doramas_button, 61, 10, 31, 8)
        self.novelas_button = pyxbmct.Button("", focusTexture=novelas2, noFocusTexture=novelas1)
        self.placeControl(self.novelas_button, 61, 18, 31, 8) 
        self.connect(self.doramas_button, self.abrir_doramas)
        self.connect(self.novelas_button, self.abrir_novelas)            


        # teste speedtest
    def speedtest_(self):
        speedtest.run_speedtest()


    def abrir_filmes(self):
        op = xbmcgui.Dialog().select('SELECIONE O TIPO', ['DIRETO', 'TORRENT'])
        # direto
        if op == 0:
            op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['OPÇÃO 1', 'OPÇÃO 2'])
            if op >= 0:
                # opcao 1
                if op == 0:
                    op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['PESQUISAR', 'FILMES'])
                    if op >= 0:
                        if op == 0:
                            text = input_text('Pesquise um filme')
                            if text:
                                tela_vod1.painel_vod1(search=text, mode='pesquisa')
                        elif op == 1:
                            tela_vod1.painel_vod1(search=None, mode='filmes')

                elif op == 1:
                    op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['PESQUISAR', 'FILMES'])
                    if op >= 0:
                        if op == 0:
                            text = input_text('Pesquise um filme')
                            if text:
                                tela_vod2.painel_vod2(search=text, mode='pesquisa')
                        elif op == 1:
                            tela_vod2.painel_vod2(search=None, mode='filmes')                            
        # torrent
        elif op == 1:
            op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['PESQUISAR', 'LANÇAMENTO', 'POPULARES'])
            if op >= 0:
                if op == 0:
                    text = input_text('Pesquise um filme')
                    if text:
                        tela_torrent.painel_torrent(search=text, url_filmes='https://gist.github.com/zoreu/10c194c495d71741eb566d45d3f30b2f')

                elif op == 1:
                    tela_torrent.painel_torrent(search=None, url_filmes='https://gist.github.com/zoreu/10c194c495d71741eb566d45d3f30b2f')
                elif op == 2:
                    tela_torrent.painel_torrent(search=None, url_filmes='https://gist.github.com/zoreu/253870092ac8282e3874fa7e1b89611f')


    def abrir_series(self):
        op = xbmcgui.Dialog().select('SELECIONE O TIPO', ['DIRETO', 'TORRENT'])
        # direto
        if op == 0:
            op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['OPÇÃO 1', 'OPÇÃO 2'])
            if op >= 0:
                # opcao 1
                if op == 0:
                    op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['PESQUISAR', 'SÉRIES'])
                    if op >= 0:
                        if op == 0:
                            text = input_text('Pesquise uma série')
                            if text:
                                tela_vod1_series.painel_vod1(search=text, mode='pesquisa')
                        elif op == 1:
                            tela_vod1_series.painel_vod1(search=None, mode='series')

                elif op == 1:
                    op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['PESQUISAR', 'SÉRIES'])
                    if op >= 0:
                        if op == 0:
                            text = input_text('Pesquise um filme')
                            if text:
                                tela_vod2_series.painel_vod2(search=text, mode='pesquisa')
                        elif op == 1:
                            tela_vod2_series.painel_vod2(search=None, mode='series')                            
        # torrent
        elif op == 1:
            op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['PESQUISAR', 'SÉRIES'])
            if op >= 0:
                if op == 0:
                    text = input_text('Pesquise uma Série')
                    if text:
                        tela_torrent_series.painel_torrent(search=text, url_filmes='https://gist.github.com/zoreu/523a40431427624f252fc7de204eef08')
                elif op == 1:
                    tela_torrent_series.painel_torrent(search=None, url_filmes='https://gist.github.com/zoreu/523a40431427624f252fc7de204eef08')

    def abrir_tv(self):
        op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['JOGOS AO VIVO', 'LISTAS IPTV', 'LISTAS STALKER'])
        if op == 0:
            tela_jogos.jogos_window()  # Chama a função para abrir a tela de jogos
        elif op == 1:
            # lista offline 4 - https://paste.kodi.tv/ekorumaguq
            # lista atualizada - https://paste.kodi.tv/zijeyovelu
            chan = github.last_gist('https://gist.github.com/zoreu/534079c0929497e1f070a5f32e568a02')
            iptv = xtream.parselist(chan)
            if iptv:
                servers_list = ['SERVIDOR %s'%str(n + 1) for n, (dns,username,password) in enumerate(iptv)]
                server_iptv = xbmcgui.Dialog().select('SELECIONE UM SERVIDOR', servers_list)
                if server_iptv >= 0:
                    dns = iptv[server_iptv][0]
                    username = iptv[server_iptv][1]
                    password = iptv[server_iptv][2]
                    tela_iptv.tela_xtream(dns,username,password)
            else:
                xbmcgui.Dialog().notification("Erro", "Falha ao carregar servidores", xbmcgui.NOTIFICATION_INFO)
        elif op == 2:
            xbmcgui.Dialog().notification("Info", "Aguarde...", xbmcgui.NOTIFICATION_INFO)
            chan = github.last_gist('https://gist.github.com/zoreu/312f623767cba7584883294a8fcc0937')
            iptv = xtream_stalker.parselist(chan)
            if iptv:
                servers_list = ['SERVIDOR %s'%str(n + 1) for n, (dns,mac) in enumerate(iptv)]
                server_iptv = xbmcgui.Dialog().select('SELECIONE UM SERVIDOR', servers_list)
                if server_iptv >= 0:
                    dns = iptv[server_iptv][0]
                    mac = iptv[server_iptv][1]
                    tela_stalker.tela_stalker_(dns,mac)

    def abrir_doramas(self):
        op = xbmcgui.Dialog().select('SELECIONE A OPÇÃO', ['PESQUISAR', 'DORAMAS'])
        if op >= 0:
            if op == 0:
                text = input_text('Pesquise um dorama')
                if text:
                    tela_vod_doramas.painel_doramas(search=text, mode='pesquisa')
            elif op == 1:
                tela_vod_doramas.painel_doramas(search=None, mode='series')

    def abrir_novelas(self):
        tela_vod_novelas.painel_novelas(search=None, mode='series')


                    


    def set_navigation(self):
        self.live_button.controlRight(self.filmes_button)
        self.filmes_button.controlRight(self.series_button)
        self.filmes_button.controlLeft(self.live_button)
        self.series_button.controlLeft(self.filmes_button)
        self.series_button.controlDown(self.voltar_button)
        if six.PY3:
            self.series_button.controlRight(self.speedtest_button)
            self.speedtest_button.controlLeft(self.series_button)
            self.speedtest_button.controlDown(self.voltar_button)
        self.live_button.controlDown(self.doramas_button)
        self.doramas_button.controlUp(self.live_button)
        self.doramas_button.controlRight(self.novelas_button)
        self.novelas_button.controlUp(self.filmes_button)
        self.novelas_button.controlLeft(self.doramas_button)
        self.filmes_button.controlDown(self.novelas_button)
        self.doramas_button.controlDown(self.voltar_button)
        self.novelas_button.controlDown(self.voltar_button)
        self.voltar_button.controlRight(self.deslogar_button)
        self.deslogar_button.controlLeft(self.voltar_button)
        self.voltar_button.controlUp(self.novelas_button)
        self.deslogar_button.controlUp(self.novelas_button)

    def botoes_sair(self):
        self.voltar_button = pyxbmct.Button("", focusTexture=voltar_hover, noFocusTexture=voltar_normal)
        self.placeControl(self.voltar_button, 120, 18, 24, 7)
        self.connect(self.voltar_button, lambda: fechar_janela(self))
        self.deslogar_button = pyxbmct.Button("", focusTexture=deslogar_hover, noFocusTexture=deslogar_normal)
        self.placeControl(self.deslogar_button, 120, 26, 24, 7)
        self.connect(self.deslogar_button, lambda: deslogar(self))                 
        

    def set_vencimento_info(self):
        vencimento = acesso.login_info()
        if vencimento:
            self.vencimento_texto = pyxbmct.Label("Vencimento: %s"%vencimento, textColor="0xFFFFFF00", font='font40', alignment=pyxbmct.ALIGN_CENTER)
            self.placeControl(self.vencimento_texto, 140, 11, 15, 28)

