try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
from bs4 import BeautifulSoup
try:
    from lib import jsunpack
except ImportError:
    import jsunpack
import re
try:
    from lib.dns import CloudflareHTTP
except ImportError:
    from dns import CloudflareHTTP

#https://embedcanaistv.com

servers = {'premierefc': 'https://embedcanaistv.club/premiereclubes/video.m3u8',
           'premiere2': 'https://embedcanaistv.club/premiere2/video.m3u8',
           'premiere3': 'https://embedcanaistv.club/premiere3/video.m3u8',
           'premiere4': 'https://embedcanaistv.club/premiere4/video.m3u8',
           'premiere5': 'https://embedcanaistv.club/premiere5/video.m3u8',
           'premiere6': 'https://embedcanaistv.club/premiere6/video.m3u8',
           'premiere7': 'https://embedcanaistv.club/premiere7/video.m3u8',
           'premire8': 'https://embedcanaistv.club/premiere8/video.m3u8',
           'globoba': 'https://embedcanaistv.club/globoba/video.m3u8',
           'globodf': 'https://embedcanaistv.club/globodf/video.m3u8',
           'globomg': 'https://embedcanaistv.club/globomg/video.m3u8',
           'globorj': 'https://embedcanaistv.club/globorj/video.m3u8',
           'globo': 'https://embedcanaistv.club/globorj/video.m3u8',
           'globors': 'https://embedcanaistv.club/globors/video.m3u8',
           'globosp': 'https://embedcanaistv.club/globosp/video.m3u8',
           'disney+premium': 'https://embedcanaistv.club/disneyplus/video.m3u8',
           'espn': 'https://embedcanaistv.club/espn/video.m3u8',
           'espn2': 'https://embedcanaistv.club/espn2/video.m3u8',
           'espn3': 'https://embedcanaistv.club/espn3/video.m3u8',
           'espn4': 'https://embedcanaistv.club/espn4/video.m3u8',
           'tvcultura': 'https://embedcanaistv.club/tvcultura/video.m3u8',
           'max': 'https://embedcanaistv.club/max/video.m3u8',
           'space': 'https://embedcanaistv.club/space/video.m3u8',
           'tnt': 'https://embedcanaistv.club/tnt/video.m3u8',
           'sbt': 'https://embedcanaistv.club/sbtsp/video.m3u8',
           'cazétv': 'https://embedcanaistv.club/cazetv/video.m3u8'
           }


     

def get_packed_data(html):
    packed_data = ''
    try:
        for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
            else:
                t = r.split('eval')
                t = ['eval' + x for x in t if x]
                for r in t:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
    except:
        pass
    return packed_data


def catalogo_jogos():
    jogos = []
    base_site = 'https://www.futebolnatv.com.br'
    url = 'https://www.futebolnatv.com.br/eventos/jogos-hoje'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 'Referer': 'https://www.futebolnatv.com.br/jogos-hoje/', 'turbo-frame': 'xday'}
    response = CloudflareHTTP.get(url,headers=headers)
    if response['response'].status_code == 200:
        html = response['response'].text
        soup = BeautifulSoup(html, 'html.parser')
        j = soup.find('ul', {'class': 'collection'}).find_all('div', {'class': 'gamecard'})
        if j:
            for n, i in enumerate(j):
                try:
                    ads = i.find('ins', {'class': 'adsbygoogle ad-container'})
                except:
                    ads = False
                if ads:
                    continue
                else:          
                    time = i.find('div', {'class': 'box_time'}).text.strip()
                    equipe1 = i.find_all('div', {'box_time_logo_title win'})[0]
                    equipe2 = i.find_all('div', {'box_time_logo_title win'})[1]
                    try:
                        equipe1_name = equipe1.text.strip().split('\n')[0]
                    except:
                        equipe1_name = equipe1.text.strip()
                    try:
                        equipe2_name = equipe2.text.strip().split('\n')[0]
                    except:
                        equipe2_name = equipe2.text.strip()                    
                    img_equipe1 = base_site + equipe1.find('img').get('data-src') if equipe1.find('img').get('data-src') else ''
                    img_equipe2 = base_site + equipe2.find('img').get('data-src') if equipe2.find('img').get('data-src') else ''
                    jogo_name = equipe1_name + ' x ' + equipe2_name + ' - ' + time
                    if not '(F)' in jogo_name:
                        canais = i.find_all('span', {'class': 'svg-icon svg-icon-2hx svg-icon-primary me-3'})
                        if canais:
                            streams = []
                            for i in canais:
                                chan = i.text.strip().lower().replace(' ', '')
                                try:
                                    chan = chan.split(',')[0]
                                except:
                                    pass
                                # pega stream
                                stream = servers.get(chan)
                                #stream = chan
                                if stream:
                                    streams.append(stream)
                            if streams:
                                channel = {'name': jogo_name, 'equipe1_logo': img_equipe1, 'equipe2_logo': img_equipe2, 'streams': streams}
                                jogos.append(channel)
    return jogos

def get_stream(url):
    if 'embedcanaistv.club' in url:
        headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
                        'Origin': 'http://embedcanaistv.com',
                        'Referer': 'http://embedcanaistv.com/'
                        }
        response = CloudflareHTTP.get(url,headers=headers_base)
        if response['response'].status_code == 200:
            source = response['response'].text
            host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
            path = re.findall(r'^.*\.m3u8$', source, re.MULTILINE)[0] 
            stream_final = host_ + path  + '|Host=' + response['headers']['Host'] + '&Origin=' + response['headers']['Origin'] + '&Referer=' + response['headers']['Referer']
            return stream_final
        else:
            stream_final = ''    
            return stream_final
