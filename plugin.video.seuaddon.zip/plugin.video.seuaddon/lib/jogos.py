import urllib.request
from urllib.error import HTTPError, URLError
try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
from bs4 import BeautifulSoup
try:
    from lib import jsunpack
except ImportError:
    import jsunpack
import re
try:
    from lib import dns
except ImportError:
    import dns
import requests

servers = {'premierefc': 'https://embedcanaistv.com/premiereclubes',
           'premiere2': 'https://embedcanaistv.com/premiere2',
           'premiere3': 'https://embedcanaistv.com/premiere3',
           'premiere4': 'https://embedcanaistv.com/premiere4',
           'premiere5': 'https://embedcanaistv.com/premiere5',
           'premiere6': 'https://embedcanaistv.com/premiere6',
           'premiere7': 'https://embedcanaistv.com/premiere7',
           'premire8': 'https://embedcanaistv.com/premiere8',
           'globoba': 'https://embedcanaistv.com/globoba/',
           'globodf': 'https://embedcanaistv.com/globodf/',
           'globomg': 'https://embedcanaistv.com/globomg/',
           'globorj': 'https://embedcanaistv.com/globorj/',
           'globo': 'https://embedcanaistv.com/globorj/',
           'globors': 'https://embedcanaistv.com/globors/',
           'globosp': 'https://embedcanaistv.com/globosp/',
           'disney+premium': 'https://embedcanaistv.com/disneyplus/',
           'espn': 'https://embedcanaistv.com/espn/',
           'espn2': 'https://embedcanaistv.com/espn2/',
           'espn3': 'https://embedcanaistv.com/espn3/',
           'espn4': 'https://embedcanaistv.com/espn4/',
           'tvcultura': 'https://embedcanaistv.com/tvcultura',
           'max': 'https://embedcanaistv.com/max/',
           'space': 'https://embedcanaistv.com/space',
           'tnt': 'https://embedcanaistv.com/tnt',
           'sbt': 'https://embedcanaistv.com/sbtsp',
           'cazétv': 'https://embedcanaistv.com/cazetv/'
           }


def client(url, headers_=None):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
    }
    if headers_:
        headers.update(headers_)
    
    req = urllib.request.Request(url, headers=headers)
    try:
        # Realizando a requisição e recebendo a resposta
        with urllib.request.urlopen(req) as response:
            # Lendo o conteúdo da resposta
            data = response.read()
            try:
                data = data.decode('utf-8')                
            except:
                pass
            return data
    except HTTPError as e:
        # Se ocorrer um erro HTTP (ex: 404, 500), exibe o código de status
        try:
            msg = 'Erro HTTP: %s - %s'%(e.code, e.reason)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass
    except URLError as e:
        # Se ocorrer um erro de URL (ex: não conseguiu conectar), exibe a razão do erro
        try:
            msg = 'Erro de URL: %s'%(e.reason)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass            
    except Exception as e:
        # Captura qualquer outro erro não esperado
        try:
            msg = 'Erro desconhecido: %s'%(str(e))
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass

def make_request(url, headers={}):
    try:
        response = requests.get(url,headers=headers, verify=False)
        response.raise_for_status()  # Lança um erro para códigos de status HTTP 4xx e 5xx
        return response

    except requests.exceptions.HTTPError as errh:
        if response.status_code in [404, 500, 502, 503, 403, 402]:
            try:
                msg = 'HTTP Error: %s - %s'%(response.status_code, response.reason)
                xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
            except:
                pass            
        else:
            try:
                msg = 'Unexpected HTTP Error: %s - %s'%(response.status_code, response.reason)
                xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
            except:
                pass              

    except requests.exceptions.ConnectionError as errc:
        try:
            msg = 'Error Connecting: %s'%(errc)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass         

    except requests.exceptions.Timeout as errt:
        try:
            msg = 'Timeout Error: %s'%(errt)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass          

    except requests.exceptions.RequestException as err:
        try:
            msg = 'Error: %s'%(err)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass      

def get_packed_data(html):
    packed_data = ''
    try:
        for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
            else:
                t = r.split('eval')
                t = ['eval' + x for x in t if x]
                for r in t:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
    except:
        pass
    return packed_data


def catalogo_jogos():
    jogos = []
    base_site = 'https://www.futebolnatv.com.br'
    html = client('https://www.futebolnatv.com.br/eventos/jogos-hoje', {'Referer': 'https://www.futebolnatv.com.br/jogos-hoje/', 'turbo-frame': 'xday'})
    soup = BeautifulSoup(html, 'html.parser')
    j = soup.find('ul', {'class': 'collection'}).find_all('div', {'class': 'gamecard'})
    if j:
        for n, i in enumerate(j):
            try:
                ads = i.find('ins', {'class': 'adsbygoogle ad-container'})
            except:
                ads = False
            if ads:
                continue
            else:          
                time = i.find('div', {'class': 'box_time'}).text.strip()
                equipe1 = i.find_all('div', {'box_time_logo_title win'})[0]
                equipe2 = i.find_all('div', {'box_time_logo_title win'})[1]
                try:
                    equipe1_name = equipe1.text.strip().split('\n')[0]
                except:
                    equipe1_name = equipe1.text.strip()
                try:
                    equipe2_name = equipe2.text.strip().split('\n')[0]
                except:
                    equipe2_name = equipe2.text.strip()                    
                img_equipe1 = base_site + equipe1.find('img').get('data-src') if equipe1.find('img').get('data-src') else ''
                img_equipe2 = base_site + equipe2.find('img').get('data-src') if equipe2.find('img').get('data-src') else ''
                jogo_name = equipe1_name + ' x ' + equipe2_name + ' - ' + time
                if not '(F)' in jogo_name:
                    canais = i.find_all('span', {'class': 'svg-icon svg-icon-2hx svg-icon-primary me-3'})
                    if canais:
                        streams = []
                        for i in canais:
                            chan = i.text.strip().lower().replace(' ', '')
                            try:
                                chan = chan.split(',')[0]
                            except:
                                pass
                            # pega stream
                            stream = servers.get(chan)
                            #stream = chan
                            if stream:
                                streams.append(stream)
                        if streams:
                            channel = {'name': jogo_name, 'equipe1_logo': img_equipe1, 'equipe2_logo': img_equipe2, 'streams': streams}
                            jogos.append(channel)
    return jogos

def get_stream(url):
    if 'embedcanaistv.com' in url:
        headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
                        'Origin': 'http://embedcanaistv.com',
                        'Referer': 'http://embedcanaistv.com/'
                        }
        info = dns.dns_resolver_iptv(url,headers_base)
        url = info['url']
        headers = info['headers']
        html = make_request(url,headers).text
        stream = re.findall(r'\?"(.*?)"', html)
        if stream:
            info = dns.dns_resolver_iptv(stream[0],headers_base)
            stream_ = info['url']
            headers = info['headers']
            source = make_request(stream_,headers).text
            host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
            path = re.findall(r'^.*\.m3u8$', source, re.MULTILINE)[0]
            stream_final = host_ + path  + '|Host=' + headers['Host'] + '&Origin=' + headers['Origin'] + '&Referer=' + headers['Referer']
            return stream_final
        else:
            stream = ''
            return stream
    else:
        stream = ''
        return stream 
