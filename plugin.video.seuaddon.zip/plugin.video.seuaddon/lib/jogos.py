try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
from bs4 import BeautifulSoup
try:
    from lib import jsunpack
except ImportError:
    import jsunpack
import re
try:
    from lib.dns import CloudflareHTTP
except ImportError:
    from dns import CloudflareHTTP
import requests
from bs4 import BeautifulSoup

#https://embedcanaistv.com
#https://reidoscanais.tv/
#https://embedmax.site/
#https://multicanais.art/ao-vivo/canais-de-esporte-ao-vivo/



servers = {'premierefc': 'https://super-cdn.link/premiereclubes/index.m3u8',
           'premiere2': 'https://super-cdn.link/premiere2/index.m3u8',
           'premiere3': 'https://super-cdn.link/premiere3/index.m3u8',
           'premiere4': 'https://super-cdn.link/premiere4/index.m3u8',
           'premiere5': 'https://super-cdn.link/premiere5/index.m3u8',
           'premiere6': 'https://super-cdn.link/premiere6/index.m3u8',
           'premiere7': 'https://super-cdn.link/premiere7/index.m3u8',
           'premiere8': 'https://super-cdn.link/premiere8/index.m3u8',
           'globoba': 'https://anonstream.zip/globope-globonordeste/index.m3u8',
           'globodf': 'https://anonstream.zip/globodf-globobrasilia/index.m3u8',
           'globomg': 'https://anonstream.zip/globomg-globominas/index.m3u8',
           'globorj': 'https://anonstream.zip/globorj-globorio/index.m3u8',
           'globo': 'https://anonstream.zip/globorj-globorio/index.m3u8',
           'globors': 'https://anonstream.zip/globors-rbstvcaxiasdosul/index.m3u8',
           'globosp': 'https://anonstream.zip/globosp-globosaopaulo/index.m3u8',
           'disney+premium': 'https://embedcanaistv.club/disneyplus/video.m3u8',
           'disney+': 'https://embedcanaistv.club/disneyplus/video.m3u8',
           'espn': 'https://super-cdn.link/espn/index.m3u8',
           'espn2': 'https://super-cdn.link/espn2/index.m3u8',
           'espn3': 'https://super-cdn.link/espn3/index.m3u8',
           'espn4': 'https://super-cdn.link/espn4/index.m3u8',
           'tvcultura': 'https://anonstream.zip/tvcultura/index.m3u8',
           'max': 'https://embedcanaistv.club/max/video.m3u8',
           'space': 'https://super-cdn.link/space/index.m3u8',
           'tnt': 'https://super-cdn.link/tnt/index.m3u8',
           'sbt': 'https://cdn.live.br1.jmvstream.com/w/LVW-10801/LVW10801_Xvg4R0u57n/playlist.m3u8',
           'cazétv': 'https://super-cdn.link/cazetv/index.m3u8',
           'band': 'https://embedcanaistv.club/bandsp/video.m3u8'
           }


     

def get_packed_data(html):
    packed_data = ''
    try:
        for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
            else:
                t = r.split('eval')
                t = ['eval' + x for x in t if x]
                for r in t:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
    except:
        pass
    return packed_data

class cazetv:
    def __init__(self):
        self.yt = 'https://www.youtube.com'
        self.url = '%s/@CazeTV'%self.yt
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}

    def filtrar_canais(self):
        try:
            r = requests.get(self.url,headers=self.headers)
            src = r.text
            ids_ = re.findall(r'"watchEndpoint":{"videoId":"(.*?)",', src)
            if len(ids_) > 2:
                filter_ids = ids_[0:3]
            else:
                filter_ids = ids_[0]
        except:
            return []
        return filter_ids
    
    def streams(self):
        lista_ = self.filtrar_canais()
        if lista_:
            ids_ = [self.yt + '/watch?v=' + id_ for id_ in lista_]
        else:
            ids_ = []
        return ids_
    
    def stream(self,url):
        link = ''
        try:
            r = requests.get(url,headers=self.headers)
            src = r.text
            link = re.findall(r'"hlsManifestUrl":"(https:\/\/manifest\.googlevideo\.com\/api\/manifest\/hls_variant\/[^"]+)"', src)[0]
            link = link + '|User-Agent=' + self.headers['User-Agent'] + '&Origin=' + self.yt + '&Referer=' + self.yt + '/' 
        except:
            link = ''       
        return link


def catalogo_jogos():
    jogos = []
    base_site = 'https://www.futebolnatv.com.br'
    url = 'https://www.futebolnatv.com.br/eventos/jogos-hoje'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 'Referer': 'https://www.futebolnatv.com.br/jogos-hoje/', 'turbo-frame': 'xday'}
    response = CloudflareHTTP.get(url,headers=headers)
    if response and 'response' in response: 
        if response['response'].status_code == 200:
            html = response['response'].text
            soup = BeautifulSoup(html, 'html.parser')
            j = soup.find('ul', {'class': 'collection'}).find_all('div', {'class': 'gamecard'})
            if j:
                for n, i in enumerate(j):
                    try:
                        ads = i.find('ins', {'class': 'adsbygoogle ad-container'})
                    except:
                        ads = False
                    if ads:
                        continue
                    else:          
                        time = i.find('div', {'class': 'box_time'}).text.strip()
                        equipe1 = i.find_all('div', {'box_time_logo_title win'})[0]
                        equipe2 = i.find_all('div', {'box_time_logo_title win'})[1]
                        try:
                            equipe1_name = equipe1.text.strip().split('\n')[0]
                        except:
                            equipe1_name = equipe1.text.strip()
                        try:
                            equipe2_name = equipe2.text.strip().split('\n')[0]
                        except:
                            equipe2_name = equipe2.text.strip()                    
                        img_equipe1 = base_site + equipe1.find('img').get('data-src') if equipe1.find('img').get('data-src') else ''
                        img_equipe2 = base_site + equipe2.find('img').get('data-src') if equipe2.find('img').get('data-src') else ''
                        jogo_name = equipe1_name + ' x ' + equipe2_name + ' - ' + time
                        if not '(F)' in jogo_name:
                            canais = i.find_all('span', {'class': 'svg-icon svg-icon-2hx svg-icon-primary me-3'})
                            if canais:
                                streams = []
                                for i in canais:
                                    chan = i.text.strip().lower().replace(' ', '')
                                    try:
                                        chan = chan.split(',')[0]
                                    except:
                                        pass
                                    # pega stream
                                    if chan == 'cazétv':
                                        st = cazetv().streams()
                                        if st:
                                            for i in st:
                                                streams.append(i)
                                        else:
                                            stream = servers.get(chan)
                                            #stream = chan
                                            if stream:
                                                streams.append(stream)                                                
                                    else:
                                        stream = servers.get(chan)
                                        #stream = chan
                                        if stream:
                                            streams.append(stream)
                                if streams:
                                    channel = {'name': jogo_name, 'equipe1_logo': img_equipe1, 'equipe2_logo': img_equipe2, 'streams': streams}
                                    jogos.append(channel)
    return jogos


def get_stream(url):
    stream_final = ''
    if 'embedcanaistv.club' in url:
        headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
                        'Origin': 'http://embedcanaistv.com',
                        'Referer': 'http://embedcanaistv.com/'
                        }
        response = CloudflareHTTP.get(url,headers=headers_base,timeout=4)
        if response and 'response' in response: 
            if response['response'].status_code == 200:
                source = response['response'].text
                url = response['url']
                host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
                path = re.findall(r'^.*\.m3u8$', source, re.MULTILINE)[0] 
                stream_final = host_ + path  + '|Host=' + response['headers']['Host'] + '&Origin=' + response['headers']['Origin'] + '&Referer=' + response['headers']['Referer']
            else:
                stream_final = ''
        else:
            stream_final = ''
    elif 'abc.embedmax.site' in url:
        headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
                        'Origin': 'https://embedmax.site',
                        'Referer': 'https://embedmax.site/'
                        } 
        response = CloudflareHTTP.get(url,headers=headers_base,timeout=4)
        if response and 'response' in response: 
            if response['response'].status_code == 200:
                source = response['response'].text
                url = response['url']
                host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
                path = re.findall(r'^.*\.m3u8$', source, re.MULTILINE)[0] 
                stream_final = host_ + path  + '|Host=' + response['headers']['Host'] + '&Origin=' + response['headers']['Origin'] + '&Referer=' + response['headers']['Referer']
            else:
                stream_final = ''
        else:
            stream_final = ''
    elif 'anonstream.zip' in url:
        headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
                        'Origin': 'https://jalynrabei.com',
                        'Referer': 'https://jalynrabei.com/'
                        } 
        response = CloudflareHTTP.get(url,headers=headers_base,timeout=4)
        if response and 'response' in response: 
            if response['response'].status_code == 200:
                source = response['response'].text
                url = response['url']
                host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
                path = re.findall(r'^.*\.m3u8$', source, re.MULTILINE)[0] 
                stream_final = host_ + path  + '|Host=' + response['headers']['Host'] + '&Origin=' + response['headers']['Origin'] + '&Referer=' + response['headers']['Referer']
            else:
                stream_final = ''
        else:
            stream_final = ''

    elif 'uper-cdn.link' in url:
        headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
                        'Origin': 'https://vivolixopano.com',
                        'Referer': 'https://vivolixopano.com/'
                        } 
        response = CloudflareHTTP.get(url,headers=headers_base,timeout=4)
        if response and 'response' in response: 
            if response['response'].status_code == 200:
                source = response['response'].text
                url = response['url']
                host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
                path = re.findall(r'^.*\.m3u8$', source, re.MULTILINE)[0] 
                stream_final = host_ + path  + '|Host=' + response['headers']['Host'] + '&Origin=' + response['headers']['Origin'] + '&Referer=' + response['headers']['Referer']
            else:
                stream_final = ''
        else:
            stream_final = ''
    elif 'cdn.live.br1.jmvstream.com' in url:
        headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
                        'Origin': 'https://embedmax.site',
                        'Referer': 'https://embedmax.site/'
                        } 
        return url + '|User-Agent=' + headers_base['User-Agent'] + '&Origin=' + headers_base['Origin'] + '&Referer=' + headers_base['Referer']
    elif 'youtube' in url:
        return cazetv().stream(url)


    return stream_final

# url = 'https://abc.embedmax.site/band/video.m3u8'
# headers_base = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
#                         'Origin': 'https://embedmax.site',
#                         'Referer': 'https://embedmax.site/'
#                         }  
# response = CloudflareHTTP.get(url,headers=headers_base)
# if response and 'response' in response: 
#     if response['response'].status_code == 200:
#         print(response['response'].text)

# print(get_stream('https://www.youtube.com/watch?v=vWZ60QXjFB0'))