try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
try:
    from lib import dns
except ImportError:
    import dns
try:
    from lib.dns import CloudflareHTTP
except:
    from dns import CloudflareHTTP
import six


base_host = 'https://spartan.oneplayhd.com'

def yesno(heading="",message="",nolabel="Nao",yeslabel="Sim"):
    if not heading:
        heading = 'SPARTAN'
    if six.PY2:
        q = xbmcgui.Dialog().yesno(heading=heading, line1=message, nolabel=nolabel, yeslabel=yeslabel)
    else:
        q = xbmcgui.Dialog().yesno(heading=heading, message=message, nolabel=nolabel, yeslabel=yeslabel)
    return q 

def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string 

def input_text(heading='Put text'):
    vq = get_search_string(heading=heading, message="")        
    if ( not vq ): return False
    return vq

def dialog(msg):
    dialog = xbmcgui.Dialog()
    dialog.ok('SPARTAN', msg)
          

def getsetting(name):
    addon = xbmcaddon.Addon()
    return addon.getSetting(name)

def setsetting(key,value):
    addon = xbmcaddon.Addon()
    return addon.setSetting(key, value)

def access():
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
    username = getsetting('username')
    password = getsetting('password')
    username_ = base64.b64encode(username.encode()).decode('utf-8')
    password_ = base64.b64encode(password.encode()).decode('utf-8') 
    url = '%s/?action=acesso&username=%s&password=%s'%(base_host,quote_plus(username_),quote_plus(password_))
    r = CloudflareHTTP.get(url,headers=headers)
    if r and 'response' in r:   
        if r['response'].status_code == 200:
            html = r['response'].text
        else:
            html = ''
    else:
        html = ''  
    if html:
        if str(html) == 'ativado':
            return True
    return False

def login_info():
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
    username = getsetting('username')
    password = getsetting('password')
    username_ = base64.b64encode(username.encode()).decode('utf-8')
    password_ = base64.b64encode(password.encode()).decode('utf-8')
    url = 'https://spartan.oneplayhd.com/?action=vencimento&username=%s&password=%s'%(quote_plus(username_),quote_plus(password_))
    r = CloudflareHTTP.get(url,headers=headers) 
    if r and 'response' in r:   
        if r['response'].status_code == 200:
            html = r['response'].text
        else:
            html = ''
    else:
        html = ''    
    return html       


