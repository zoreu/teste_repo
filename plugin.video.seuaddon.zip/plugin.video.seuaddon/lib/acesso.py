try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
try:
    from lib import dns
except ImportError:
    import dns
try:
    from lib.dns import CloudflareHTTP
except:
    from dns import CloudflareHTTP


base_host = 'https://spartan.oneplayhd.com'
          

def getsetting(name):
    addon = xbmcaddon.Addon()
    return addon.getSetting(name)

def setsetting(key,value):
    addon = xbmcaddon.Addon()
    return addon.setSetting(key, value)

def access():
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
    username = getsetting('username')
    password = getsetting('password')
    username_ = base64.b64encode(username.encode()).decode('utf-8')
    password_ = base64.b64encode(password.encode()).decode('utf-8') 
    url = '%s/?action=acesso&username=%s&password=%s'%(base_host,quote_plus(username_),quote_plus(password_))
    r = CloudflareHTTP.get(url,headers=headers)
    if r['response'].status_code == 200:
        html = r['response'].text
    else:
        html = ''
    if html:
        if str(html) == 'ativado':
            return True
    return False

def login_info():
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
    username = getsetting('username')
    password = getsetting('password')
    username_ = base64.b64encode(username.encode()).decode('utf-8')
    password_ = base64.b64encode(password.encode()).decode('utf-8')
    url = 'https://spartan.oneplayhd.com/?action=vencimento&username=%s&password=%s'%(quote_plus(username_),quote_plus(password_))
    r = CloudflareHTTP.get(url,headers=headers)    
    if r['response'].status_code == 200:
        html = r['response'].text
    else:
        html = ''    
    return html       


