import urllib.request
from urllib.error import HTTPError, URLError
try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
try:
    from lib import dns
except ImportError:
    import dns
import requests

base_host = 'https://spartan.oneplayhd.com'

# def client(url):
#     parsed_url = urlparse(url)
#     origin = '%s://%s'%(parsed_url.scheme,parsed_url.hostname)
#     headers = {
#         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
#     }
#     req = urllib.request.Request(url, headers=headers)
#     try:
#         # Realizando a requisição e recebendo a resposta
#         with urllib.request.urlopen(req) as response:
#             # Lendo o conteúdo da resposta
#             data = response.read()
#             try:
#                 data = data.decode('utf-8')                
#             except:
#                 pass
#             return data
#     except HTTPError as e:
#         # Se ocorrer um erro HTTP (ex: 404, 500), exibe o código de status
#         try:
#             msg = 'Erro HTTP: %s - %s'%(e.code, e.reason)
#             xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
#         except:
#             pass
#     except URLError as e:
#         # Se ocorrer um erro de URL (ex: não conseguiu conectar), exibe a razão do erro
#         try:
#             msg = 'Erro de URL: %s'%(e.reason)
#             xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
#         except:
#             pass            
#     except Exception as e:
#         # Captura qualquer outro erro não esperado
#         try:
#             msg = 'Erro desconhecido: %s'%(str(e))
#             xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
#         except:
#             pass  

def make_request(url, headers={}):
    try:
        response = requests.get(url,headers=headers, verify=False)
        response.raise_for_status()  # Lança um erro para códigos de status HTTP 4xx e 5xx
        return response

    except requests.exceptions.HTTPError as errh:
        if response.status_code in [404, 500, 502, 503, 403, 402]:
            try:
                msg = 'HTTP Error: %s - %s'%(response.status_code, response.reason)
                xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
            except:
                pass            
        else:
            try:
                msg = 'Unexpected HTTP Error: %s - %s'%(response.status_code, response.reason)
                xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
            except:
                pass              

    except requests.exceptions.ConnectionError as errc:
        try:
            msg = 'Error Connecting: %s'%(errc)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass         

    except requests.exceptions.Timeout as errt:
        try:
            msg = 'Timeout Error: %s'%(errt)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass          

    except requests.exceptions.RequestException as err:
        try:
            msg = 'Error: %s'%(err)
            xbmcgui.Dialog().notification("Erro", msg, xbmcgui.NOTIFICATION_ERROR)
        except:
            pass               

def getsetting(name):
    addon = xbmcaddon.Addon()
    return addon.getSetting(name)

def setsetting(key,value):
    addon = xbmcaddon.Addon()
    return addon.setSetting(key, value)

def access():
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
    username = getsetting('username')
    password = getsetting('password')
    username_ = base64.b64encode(username.encode()).decode('utf-8')
    password_ = base64.b64encode(password.encode()).decode('utf-8') 
    url = '%s/?action=acesso&username=%s&password=%s'%(base_host,quote_plus(username_),quote_plus(password_))
    #url_cors = 'https://api.allorigins.win/raw?url=%s'%(quote_plus(url))
    # html = client(url_cors)
    info = dns.dns_resolver_iptv(url,headers)
    url = info['url']
    headers = info['headers']
    reponse = make_request(url,headers)
    if reponse.status_code == 200:
        html = reponse.text
    else:
        html = ''
    if html:
        if str(html) == 'ativado':
            return True
    return False

def login_info():
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
    username = getsetting('username')
    password = getsetting('password')
    username_ = base64.b64encode(username.encode()).decode('utf-8')
    password_ = base64.b64encode(password.encode()).decode('utf-8')
    url = 'https://spartan.oneplayhd.com/?action=vencimento&username=%s&password=%s'%(quote_plus(username_),quote_plus(password_))
    #url_cors = 'https://api.allorigins.win/raw?url=%s'%(quote_plus(url))
    #html = client(url_cors)
    info = dns.dns_resolver_iptv(url,headers)
    url = info['url']
    headers = info['headers']
    reponse = make_request(url,headers)
    if reponse.status_code == 200:
        html = reponse.text
    else:
        html = ''
    return html       




# def test_acess():
#     #https://gist.github.com/jimmywarting/ac1be6ea0297c16c477e17f8fbe51347
#     url = 'https://oneplayhd.com'
#     url_cors = 'https://api.allorigins.win/raw?url=%s'%(quote_plus(url))
#     html = client(url_cors)
#     print(html)

