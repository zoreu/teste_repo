try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import pyxbmct.addonwindow as pyxbmct
from lib import acesso, addon, jogos, dns_proxy2, xtream
import six
import os
from urllib.parse import urlparse, parse_qs, quote_plus
import time
import sys
import threading

addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
homeDir = addon.getAddonInfo('path')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
addonIcon = translate(os.path.join(homeDir, 'icon.png'))
kversion = int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0])


def log(txt):
    try:
        message = ''.join([addonName, ' : ', txt])
        xbmc.log(msg=message, level=xbmc.LOGDEBUG)
    except:
        pass

global tela_cond
tela_cond = False

def tela_xtream(dns, username, password):
    global tela_cond
    global categorys
    global iptv_
    if not tela_cond:
        iptv_ = xtream.API(dns, username, password)
        categorys = iptv_.channels_category()
        if categorys:
            window = IPTVInterface('spartan')
            window.doModal()
            del window 
        else:
            xbmcgui.Dialog().notification("Erro", "Servidor Offline", xbmcgui.NOTIFICATION_INFO)      

def fechar_janela(self):
    global tela_cond
    tela_cond = True
    xbmc.executebuiltin("Container.Update(path,replace)")
    self.close()
    sys.exit()

def Player_iptv(name, stream):
    xbmcgui.Dialog().notification("Info", "Aguarde!", xbmcgui.NOTIFICATION_INFO) 
    try:                
        proxy_url = dns_proxy2.url_proxy + quote_plus(stream)
        dns_proxy2.DNSProxyManager2().start()
        liz = xbmcgui.ListItem(name)
        if kversion > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setPlot("")
        else:
            liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": ""})        
        liz.setArt({"thumb": addonIcon})
        liz.setProperty('IsPlayable', 'true')
        liz.setPath(proxy_url)
    
        xbmc.Player().play(proxy_url, liz, False)
        quit()
    except:
        pass  

def category_items(self):
    global categorys
    for i in categorys:
        self.LIST_CATEGORY.addItem('[B]%s[/B]' % i['name'])

def streams_items(self, url):
    try:
        self.LIST_CHANNELS.reset()
    except:
        pass
    global streams
    global iptv_
    streams = iptv_.channels_open(url)
    for i in streams:
        self.LIST_CHANNELS.addItem('[B]%s[/B]' % i['name'])        

def clock(self):
    time2 = time.strftime("%I:%M %p")
    self.TIME.setLabel(str(time2))  

class IPTVInterface(pyxbmct.AddonFullWindow):
    def __init__(self, title="spartan"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.connect(pyxbmct.ACTION_NAV_BACK, lambda: fechar_janela(self))
        self.names_info()
        self.set_list_controls()
        self.epg()
        category_items(self)
        self.setFocus(self.LIST_CATEGORY)
        self.botao_voltar()
        self.set_navigation()

    def names_info(self):
        self.category_name = pyxbmct.Label("Categorias:", textColor="0xFFFFFF00", font='font18')
        self.placeControl(self.category_name, 22, 9, 80, 18)

        self.channels_name = pyxbmct.Label("Canais:", textColor="0xFFFFFF00", font='font18')
        self.placeControl(self.channels_name, 22, 20, 80, 18)  

        self.channels_name = pyxbmct.Label("Epg:", textColor="0xFFFFFF00", font='font18')
        self.placeControl(self.channels_name, 22, 36, 80, 18)                           

    def set_list_controls(self):
        self.LIST_CATEGORY = pyxbmct.List()
        self.placeControl(self.LIST_CATEGORY, 30, 2, 80, 14)
        self.LIST_CHANNELS = pyxbmct.List()
        self.placeControl(self.LIST_CHANNELS, 30, 16, 80, 14)

        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.update_list_channels)      
        self.connect(self.LIST_CATEGORY, lambda: streams_items(self, url_list2))
        self.connect(self.LIST_CHANNELS, lambda: Player_iptv(name_channel, stream_channel))

    def update_list_channels(self):
        global iptv_
        global categorys
        global url_list2
        global streams
        global name_channel
        global stream_channel
        try:
            if self.getFocus() == self.LIST_CATEGORY:
                position_list1 = self.LIST_CATEGORY.getSelectedPosition()
                url_list2 = categorys[position_list1]['url']
                self.epg_info.setLabel('')
        except (RuntimeError, SystemError):
            pass
        try:
            if self.getFocus() == self.LIST_CHANNELS:
                position_list2 = self.LIST_CHANNELS.getSelectedPosition()
                id_channel = streams[position_list2]['id']
                name_channel = streams[position_list2]['name']
                stream_channel = streams[position_list2]['url']
                text_epg = iptv_.get_epg(id_channel)
                if text_epg:
                    self.epg_info.setLabel(text_epg)
                else:
                    self.epg_info.setLabel('')
        except (RuntimeError, SystemError):
            pass        

    def epg(self):
        self.epg_info = pyxbmct.Label("", textColor="0xFFFFFF00", font='font18')
        self.placeControl(self.epg_info, 29, 30, 80, 18) 

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        background_image_path = translate(
            "special://home/addons/plugin.video.seuaddon/resources/media/background3.png"
        )
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.addControl(self.main_bg)

    def botao_voltar(self):
        voltar_normal = translate(
            "special://home/addons/plugin.video.seuaddon/resources/media/voltar.png"
        )
        voltar_hover = translate(
            "special://home/addons/plugin.video.seuaddon/resources/media/voltar2.png"
        )
        self.voltar_button = pyxbmct.Button("", focusTexture=voltar_hover, noFocusTexture=voltar_normal)
        self.placeControl(self.voltar_button, 132, 22, 24, 7)
        self.connect(self.voltar_button, lambda: fechar_janela(self))

    def set_navigation(self):
        self.LIST_CATEGORY.controlDown(self.voltar_button)
        self.voltar_button.controlUp(self.LIST_CATEGORY)
        self.LIST_CATEGORY.controlRight(self.LIST_CHANNELS)
        self.LIST_CHANNELS.controlLeft(self.LIST_CATEGORY)
        self.LIST_CHANNELS.controlDown(self.voltar_button)      


