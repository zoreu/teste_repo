import requests
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import re
import logging

# Configuração do logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

class CloudflareHTTP:
    @staticmethod
    def _get_info(url, headers):
        _headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
        url = url.replace('https://', 'http://')
        url_parsed = urlparse(url)
        protocol = url_parsed.scheme
        port = str(url_parsed.port) if url_parsed.port else ''
        net = url_parsed.hostname
        if port:
            host = protocol + '://' + net + ':' + port
        else:
            host = protocol + '://' + net
        ip_pattern = re.compile(r'^(https?://)?(\d{1,3}\.){3}\d{1,3}(:\d+)?(/.*)?$')
        ip_check = bool(ip_pattern.match(net))
        if ip_check:
            headers_ = _headers
            headers_.update(headers)
            info = {'url': url, 'headers': headers_}
        else:
            params = {
                "name": net,
                "type": "A"
            }
            try:
                r = requests.get('https://1.1.1.1/dns-query', headers={"Accept": "application/dns-json"}, params=params).json()
                ip_ = r['Answer'][-1].get('data', '')
            except Exception as e:
                msg = 'DNS Query Error: %s'%str(e)
                logger.error(msg)
                ip_ = net
            if ip_:
                ip = ip_
                if port:
                    new_host = protocol + '://' + ip + ':' + port
                else:
                    new_host = protocol + '://' + ip
                url_replace = url.replace(host, new_host)
                headers_ = {'Host': net}
                headers_.update(_headers)
                headers_.update(headers)
                info = {'url': url_replace, 'headers': headers_}
            else:
                raise Exception("No IP found")
        return info

    @staticmethod
    def get(url, headers={}, timeout=None, cookies=None, stream=False, allow_redirects=True):
        info = CloudflareHTTP._get_info(url, headers)
        request_headers = info['headers']
        response = {'headers': request_headers}
        try:
            r = requests.get(info['url'], headers=request_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout, stream=stream)
            r.raise_for_status() 
            if r.history:
                for resp in r.history:
                    msg = 'Redirected from %s to %s'%(resp.url,resp.headers['Location'])
                    logger.info(msg)
            response['response'] = r
            return response
        except requests.exceptions.Timeout as e:
            msg = 'Timeout Error on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.TooManyRedirects as e:
            msg = 'Too Many Redirects on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.SSLError as e:
            msg = 'SSL Error on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.ConnectionError as e:
            msg = 'Connection Error on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.HTTPError as e:
            msg = 'HTTP Error on URL: %s - Status Code: %s - Reason: %s'%(info['url'],str(e.response.status_code),str(e))
            logger.error(msg)
        except requests.exceptions.RequestException as e:
            msg = 'Request Exception on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)

    @staticmethod
    def post(url, headers={}, timeout=None, cookies=None, stream=False, data=None, json=None, allow_redirects=True):
        info = CloudflareHTTP._get_info(url, headers)
        request_headers = info['headers']
        response = {'headers': request_headers}     
        try:
            if data:
                r = requests.post(info['url'], headers=request_headers, timeout=timeout, cookies=cookies, data=data, allow_redirects=allow_redirects, stream=stream)
                r.raise_for_status() 
                response['response'] = r
                return response
            elif json:
                r = requests.post(info['url'], headers=request_headers, timeout=timeout, cookies=cookies, json=json, allow_redirects=allow_redirects, stream=stream)
                r.raise_for_status() 
                response['response'] = r
                return response
        except requests.exceptions.Timeout as e:
            msg = 'Timeout Error on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.TooManyRedirects as e:
            msg = 'Too Many Redirects on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.SSLError as e:
            msg = 'SSL Error on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.ConnectionError as e:
            msg = 'Connection Error on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)
        except requests.exceptions.HTTPError as e:
            msg = 'HTTP Error on URL: %s - Status Code: %s - Reason: %s'%(info['url'],str(e.response.status_code),str(e))
            logger.error(msg)
        except requests.exceptions.RequestException as e:
            msg = 'Request Exception on URL: %s - Reason: %s'%(info['url'],str(e))
            logger.error(msg)



# def dns_resolver_iptv(url,headers):
#     url = url.replace('https://', 'http://')
#     url_parsed = urlparse(url)
  
#     protocol = url_parsed.scheme
#     if 'https' in url:
#         port = '443'
#     else:
#         port = str(url_parsed.port) if url_parsed.port else ''
#     net = url_parsed.hostname
#     if port:
#         host = protocol + '://' + net + ':' + port
#     else:
#         host = protocol + '://' + net
#     ip_pattern = re.compile(r'^(https?://)?(\d{1,3}\.){3}\d{1,3}(:\d+)?(/.*)?$')
#     tem_ip = bool(ip_pattern.match(net))
#     if tem_ip:
#         return {'url': url, 'headers': headers}
#     else:     
#         params = {
#             "name": net,
#             "type": "A",  # Tipo de consulta DNS (A, AAAA, etc.)
#         }    
#         try:
#             r = requests.get('https://1.1.1.1/dns-query',headers={"Accept": "application/dns-json"}, params=params).json()
#             ip_ = r['Answer'][-1].get('data', '')
#         except:
#             ip_ = net
#         if ip_:
#             ip = ip_
#             if port:
#                 new_host = protocol + '://' + ip + ':' + port
#             else:
#                 new_host = protocol + '://' + ip
#             url_replace = url.replace(host, new_host)
#             headers_ = {'Host': net}
#             headers_.update(headers)
#             req_info = {'url': url_replace, 'headers': headers_}
#         else:
#             req_info = {}
#         return req_info
    
# def teste():
#     url = 'https://embedcanaistv.com/premiereclubes'
#     headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
#     info = dns_resolver_iptv(url,headers)
#     print(info['url'])
#     r = requests.get(info['url'], headers=info['headers'])
#     print(r.text)

# teste()

# def teste():
#     import re
#     #embedcanaistv.club
#     url = 'http://104.21.50.99/premiereclubes/video.m3u8'
#     #url = 'http://104.21.50.99/combate/tracks-v1a1/mono.ts.m3u8'
#     headers = {'Host': 'embedcanaistv.club',
#                'Origin': 'https://embedcanaistv.com',
#                'Referer': 'https://embedcanaistv.com/'}
#     #http://104.21.50.99/2024/12/10/03/13/28-08342.ts
#     #https://embedcanaistv.club/2024/12/10/03/13/28-08342.ts
#     r = requests.get(url,headers=headers)
#     text = r.text
#     host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
#     path = re.findall(r'^.*\.m3u8$', text, re.MULTILINE)[0]
#     stream = host_ + path
#     print(stream)

# def teste():
#     #url = 'https://spartan.oneplayhd.com'
#     url = 'https://rumble.com'
#     headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
#     info = dns_resolver_iptv(url,headers)
#     url = info['url']
#     headers = info['headers']
#     r = requests.get(url,headers=headers)
#     print(r.text)


# teste()

# import requests

# # Defina o endereço IP que simula uma localização em Nova Iorque, EUA
# ip_address = '104.131.0.171'  # Exemplo de IP de Nova Iorque

# # Cabeçalhos personalizados
# headers = {
#     'X-Forwarded-For': ip_address,
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
# }

# # URL de exemplo
# url = 'https://rumble.com'

# # Fazer a requisição
# response = requests.get(url, headers=headers)

# # Verificar e imprimir a resposta
# print(response.status_code)
# print(response.text)


# r = CloudflareHTTP.get('https://oneplayhd.com')
# src = r['response'].text
# host = r['headers']['Host']
# print(host)