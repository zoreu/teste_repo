from urllib.parse import urlparse, parse_qs, quote_plus, quote
import requests
import re

def dns_resolver_iptv(url,headers):
    url = url.replace('https://', 'http://')
    url_parsed = urlparse(url)
  
    protocol = url_parsed.scheme
    if 'https' in url:
        port = '443'
    else:
        port = str(url_parsed.port) if url_parsed.port else ''
    net = url_parsed.hostname
    if port:
        host = protocol + '://' + net + ':' + port
    else:
        host = protocol + '://' + net
    ip_pattern = re.compile(r'^(https?://)?(\d{1,3}\.){3}\d{1,3}(:\d+)?(/.*)?$')
    tem_ip = bool(ip_pattern.match(net))
    if tem_ip:
        return {'url': url, 'headers': headers}
    else:     
        params = {
            "name": net,
            "type": "A",  # Tipo de consulta DNS (A, AAAA, etc.)
        }    
        try:
            r = requests.get('https://1.1.1.1/dns-query',headers={"Accept": "application/dns-json"}, params=params).json()
            ip_ = r['Answer'][-1].get('data', '')
        except:
            ip_ = net
        if ip_:
            ip = ip_
            if port:
                new_host = protocol + '://' + ip + ':' + port
            else:
                new_host = protocol + '://' + ip
            url_replace = url.replace(host, new_host)
            headers_ = {'Host': net}
            headers_.update(headers)
            req_info = {'url': url_replace, 'headers': headers_}
        else:
            req_info = {}
        return req_info
    
# def teste():
#     url = 'https://embedcanaistv.com/premiereclubes'
#     headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
#     info = dns_resolver_iptv(url,headers)
#     print(info['url'])
#     r = requests.get(info['url'], headers=info['headers'])
#     print(r.text)

# teste()

# def teste():
#     import re
#     #embedcanaistv.club
#     url = 'http://104.21.50.99/premiereclubes/video.m3u8'
#     #url = 'http://104.21.50.99/combate/tracks-v1a1/mono.ts.m3u8'
#     headers = {'Host': 'embedcanaistv.club',
#                'Origin': 'https://embedcanaistv.com',
#                'Referer': 'https://embedcanaistv.com/'}
#     #http://104.21.50.99/2024/12/10/03/13/28-08342.ts
#     #https://embedcanaistv.club/2024/12/10/03/13/28-08342.ts
#     r = requests.get(url,headers=headers)
#     text = r.text
#     host_ = 'http://' + url.split('/')[2] + '/' + url.split('/')[3] + '/'
#     path = re.findall(r'^.*\.m3u8$', text, re.MULTILINE)[0]
#     stream = host_ + path
#     print(stream)



# teste()