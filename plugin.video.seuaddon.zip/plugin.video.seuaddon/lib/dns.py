import requests
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import re
import logging

# Configuração do logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

class CloudflareHTTP:
    @staticmethod
    def get_normal(url, headers={}, timeout=None, cookies=None, stream=False, allow_redirects=True, verify=False, log=True):
        headers_ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
        headers_.update(headers)
        request_headers = headers_
        response = {'headers': request_headers, 'url': url}        
        try:
            r = requests.get(url, headers=headers_, cookies=cookies, allow_redirects=allow_redirects, timeout=4, stream=stream, verify=verify)
            r.raise_for_status()
            if r.history:
                for resp in r.history:
                    if log:
                        msg = 'Redirected from %s to %s' % (resp.url, resp.headers['Location'])
                        logger.info(msg)
            response['response'] = r
            return response
        except requests.exceptions.Timeout as e:
            if log:
                msg = 'Timeout Error on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.TooManyRedirects as e:
            if log:
                msg = 'Too Many Redirects on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.SSLError as e:
            if log:
                msg = 'SSL Error on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.ConnectionError as e:
            if log:
                msg = 'Connection Error on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.HTTPError as e:
            if log:
                msg = 'HTTP Error on URL: %s - Status Code: %s - Reason: %s' % (url, str(e.response.status_code), str(e))
                logger.error(msg)
        except requests.exceptions.RequestException as e:
            if log:
                msg = 'Request Exception on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        return 

    @staticmethod
    def get_post(url, headers={}, timeout=None, cookies=None, stream=False, data=None, json=None, allow_redirects=True, verify=False, log=True):
        headers_ = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
        headers_.update(headers) 
        request_headers = headers_
        response = {'headers': request_headers, 'url': url}                 
        try:
            if data:
                r = requests.post(url, headers=headers_, timeout=timeout, cookies=cookies, data=data, allow_redirects=allow_redirects, stream=stream, verify=verify)
                r.raise_for_status()
                if r.history:
                    for resp in r.history:
                        if log:
                            msg = 'Redirected from %s to %s' % (resp.url, resp.headers['Location'])
                            logger.info(msg)                
                response['response'] = r
                return response            
            elif json:
                r = requests.post(url, headers=headers_, timeout=timeout, cookies=cookies, json=json, allow_redirects=allow_redirects, stream=stream, verify=verify)
                r.raise_for_status()
                if r.history:
                    for resp in r.history:
                        if log:
                            msg = 'Redirected from %s to %s' % (resp.url, resp.headers['Location'])
                            logger.info(msg)                 
                response['response'] = r
                return response   
        except requests.exceptions.Timeout as e:
            if log:
                msg = 'Timeout Error on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.TooManyRedirects as e:
            if log:
                msg = 'Too Many Redirects on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.SSLError as e:
            if log:
                msg = 'SSL Error on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.ConnectionError as e:
            if log:
                msg = 'Connection Error on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg)
        except requests.exceptions.HTTPError as e:
            if log:
                msg = 'HTTP Error on URL: %s - Status Code: %s - Reason: %s' % (url, str(e.response.status_code), str(e))
                logger.error(msg)
        except requests.exceptions.RequestException as e:
            if log:
                msg = 'Request Exception on URL: %s - Reason: %s' % (url, str(e))
                logger.error(msg) 
        return           


    @staticmethod
    def _get_info(url, headers):
        _headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}
        url = url.replace('https://', 'http://')
        url_parsed = urlparse(url)
        protocol = url_parsed.scheme
        port = str(url_parsed.port) if url_parsed.port else ''
        net = url_parsed.hostname
        if port:
            host = protocol + '://' + net + ':' + port
        else:
            host = protocol + '://' + net
        ip_pattern = re.compile(r'^(https?://)?(\d{1,3}\.){3}\d{1,3}(:\d+)?(/.*)?$')
        ip_check = bool(ip_pattern.match(net))
        if ip_check:
            headers_ = _headers
            headers_.update(headers)
            info = {'url': url, 'headers': headers_}
        else:
            params = {
                "name": net,
                "type": "A"
            }
            try:
                r = requests.get('https://1.1.1.1/dns-query', headers={"Accept": "application/dns-json"}, params=params).json()
                ip_ = r['Answer'][-1].get('data', '')
            except Exception as e:
                msg = 'DNS Query Error: %s' % str(e)
                logger.error(msg)
                ip_ = net
            if ip_:
                ip = ip_
                if port:
                    new_host = protocol + '://' + ip + ':' + port
                else:
                    new_host = protocol + '://' + ip
                url_replace = url.replace(host, new_host)
                headers_ = {'Host': net}
                headers_.update(_headers)
                headers_.update(headers)
                info = {'url': url_replace, 'headers': headers_}
            else:
                raise Exception("No IP found")
        return info

    @staticmethod
    def get(url, headers={}, timeout=None, cookies=None, stream=False, allow_redirects=True, verify=False, log=True):
        info = CloudflareHTTP._get_info(url, headers)
        request_headers = info['headers']
        response = {'headers': request_headers, 'url': info['url']}

        try:
            r = requests.get(info['url'], headers=request_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout, stream=stream, verify=verify)
            r.raise_for_status()
            if r.history:
                for resp in r.history:
                    if log:
                        msg = 'Redirected from %s to %s' % (resp.url, resp.headers['Location'])
                        logger.info(msg)
            response['response'] = r
            return response
        except requests.exceptions.Timeout as e:
            if log:
                msg = 'Timeout Error on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_normal(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, allow_redirects=allow_redirects, verify=verify, log=log)
        except requests.exceptions.TooManyRedirects as e:
            if log:
                msg = 'Too Many Redirects on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_normal(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.SSLError as e:
            if log:
                msg = 'SSL Error on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_normal(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.ConnectionError as e:
            if log:
                msg = 'Connection Error on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_normal(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.HTTPError as e:
            if log:
                msg = 'HTTP Error on URL: %s - Status Code: %s - Reason: %s' % (info['url'], str(e.response.status_code), str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_normal(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.RequestException as e:
            if log:
                msg = 'Request Exception on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_normal(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, allow_redirects=allow_redirects, verify=verify, log=log)            

    @staticmethod
    def post(url, headers={}, timeout=None, cookies=None, stream=False, data=None, json=None, allow_redirects=True, verify=False, log=True):
        info = CloudflareHTTP._get_info(url, headers)
        request_headers = info['headers']
        response = {'headers': request_headers, 'url': info['url']}
        try:
            if data:
                r = requests.post(info['url'], headers=request_headers, timeout=timeout, cookies=cookies, data=data, allow_redirects=allow_redirects, stream=stream, verify=verify)
                r.raise_for_status()
                if r.history:
                    for resp in r.history:
                        if log:
                            msg = 'Redirected from %s to %s' % (resp.url, resp.headers['Location'])
                            logger.info(msg)                 
                response['response'] = r
                return response
            elif json:
                r = requests.post(info['url'], headers=request_headers, timeout=timeout, cookies=cookies, json=json, allow_redirects=allow_redirects, stream=stream, verify=verify)
                r.raise_for_status()
                if r.history:
                    for resp in r.history:
                        if log:
                            msg = 'Redirected from %s to %s' % (resp.url, resp.headers['Location'])
                            logger.info(msg)                 
                response['response'] = r
                return response
        except requests.exceptions.Timeout as e:
            if log:
                msg = 'Timeout Error on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_post(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, data=data, json=json, allow_redirects=allow_redirects, verify=verify, log=log)
        except requests.exceptions.TooManyRedirects as e:
            if log:
                msg = 'Too Many Redirects on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_post(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, data=data, json=json, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.SSLError as e:
            if log:
                msg = 'SSL Error on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_post(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, data=data, json=json, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.ConnectionError as e:
            if log:
                msg = 'Connection Error on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_post(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, data=data, json=json, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.HTTPError as e:
            if log:
                msg = 'HTTP Error on URL: %s - Status Code: %s - Reason: %s' % (info['url'], str(e.response.status_code), str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_post(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, data=data, json=json, allow_redirects=allow_redirects, verify=verify, log=log)            
        except requests.exceptions.RequestException as e:
            if log:
                msg = 'Request Exception on URL: %s - Reason: %s' % (info['url'], str(e))
                logger.error(msg)
                msg2 = 'Using default requests with url: %s' % (url)
                logger.info(msg2) 
            return CloudflareHTTP.get_post(url, headers=headers, timeout=timeout, cookies=cookies, stream=stream, data=data, json=json, allow_redirects=allow_redirects, verify=verify, log=log)            



