import sys
import threading
try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import pyxbmct.addonwindow as pyxbmct
from lib import acesso, painel
import os
import time
from lib.images import background_image_path_login, login_button_normal, login_button_hover, cancel_button_normal, cancel_button_hover

global exit_command
exit_command = False

# def monitor():
#     monitor = xbmc.Monitor()
#     while not monitor.waitForAbort(3):
#         pass
#     #sys.exit()
#     # comando pra fechar kodi
#     try:
#         os._exit(1)
#     except:
#         pass    


def login_window():
    window = Login('Spartan')
    window.doModal()
    del window

def spartan():
    # Iniciar a thread do monitor
    # monitor_thread = threading.Thread(target=monitor)
    # monitor_thread.start()    
    global exit_command
    if not exit_command:    
        username = acesso.getsetting('username')
        password = acesso.getsetting('password')
        if not username and not password:
            login_window()
        elif acesso.access():
            painel.tela_inicial()
            exit_command = True
        else:
            login_window()
 

def clock(self):
    time2 = time.strftime("%I:%M %p")
    self.TIME.setLabel(str(time2))                

class Login(pyxbmct.AddonFullWindow):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    def __init__(self, title="Login"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.set_info_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.setFocus(self.username_input)
        self.INSTRUCTION = pyxbmct.Label('Receba acesso em https://tinyurl.com/spartanaddon', textColor='0xFFFFFF00', font='font18')
        self.placeControl(self.INSTRUCTION, 47,16, 12, 50)
        self.recupera_login() 
        self.relogio()

    def update_relogio(self):
        clock(self)        

    def relogio(self):
        self.TIME = pyxbmct.Label('',textColor='0xFFFFFFFF', font='font14')
        self.placeControl(self.TIME, 1,42, 12, 10)
        time2 = time.strftime("%I:%M %p")
        self.TIME.setLabel(str(time2))
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
            pyxbmct.ACTION_MOVE_UP,
            pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
            pyxbmct.ACTION_MOUSE_WHEEL_UP,
            pyxbmct.ACTION_MOUSE_MOVE],
            self.update_relogio)                                         

    def recupera_login(self):
        username = acesso.getsetting('username')
        password = acesso.getsetting('password')
        self.username_input.setText(username)
        self.password_input.setText(password)

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path_login)
        self.main_bg.setImage(background_image_path_login)
        self.addControl(self.main_bg)

    def set_info_controls(self):
        self.username_input = pyxbmct.Edit('', font='font40', textColor='0xFFFFFFFF', disabledColor='0xFFFFFFFF', _alignment=0, focusTexture='0xFFFFFFFF', noFocusTexture='0xFFFFFFFF')
        self.placeControl(self.username_input, 84, 20, 15, 10)
        self.password_input = pyxbmct.Edit('', font='font40', textColor='0xFFFFFFFF', disabledColor='0xFFFFFFFF', _alignment=0, focusTexture='0xFFFFFFFF', noFocusTexture='0xFFFFFFFF')
        self.placeControl(self.password_input, 102, 20, 15, 10)

        # Botão de Login com efeito de mouse-over
        self.login_button = pyxbmct.Button("", focusTexture=login_button_hover, noFocusTexture=login_button_normal)
        self.placeControl(self.login_button, 113, 15, 25, 10)
        self.connect(self.login_button, self.login_action)

        # Botão de Cancelar com efeito de mouse-over
        self.cancel_button = pyxbmct.Button("", focusTexture=cancel_button_hover, noFocusTexture=cancel_button_normal)
        self.placeControl(self.cancel_button, 113, 25, 25, 10)
        self.connect(self.cancel_button, self.close)

    def set_navigation(self):
        self.username_input.controlDown(self.password_input)
        self.password_input.controlUp(self.username_input)
        self.password_input.controlDown(self.login_button)
        self.login_button.controlUp(self.password_input)
        self.login_button.controlRight(self.cancel_button)
        self.cancel_button.controlLeft(self.login_button)

    def login_action(self):
        username = self.username_input.getText()
        password = self.password_input.getText()
        if username and password:
            acesso.setsetting('username', username)
            acesso.setsetting('password', password)
            if acesso.access():
                q = acesso.yesno('', 'Deseja ativar os conteudos Adultos?')
                if q:
                    acesso.setsetting('hidexxx', 'true')
                    adult_password = acesso.input_text('Defina a senha Parental:')
                    if not adult_password:
                        adult_password = ''
                    acesso.setsetting('parental_password', str(adult_password))
                else:
                    acesso.setsetting('hidexxx', 'false')

                # inicia o painel
                xbmcgui.Dialog().notification("Info", "Bem vindo: %s!" % username, xbmcgui.NOTIFICATION_INFO)
                painel.tela_inicial()
            else:
                xbmcgui.Dialog().notification("Erro", "Acesso Negado, tente denovo ou verifique sua conexão", xbmcgui.NOTIFICATION_ERROR)
                login_window()
        else:
            xbmcgui.Dialog().notification("Erro", "Por favor, preencha todos os campos.", xbmcgui.NOTIFICATION_ERROR)

    def close(self):
        global exit_command
        exit_command = True
        xbmc.executebuiltin("Container.Update(path,replace)")
        xbmc.executebuiltin("Container.Refresh()")
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ActivateWindow(Home)")
        super().close()
        try:
            sys.exit()
        except:
            pass


