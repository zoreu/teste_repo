try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import pyxbmct.addonwindow as pyxbmct
from lib import acesso, addon, torrent_scrape, scrape_vod, resolverlib
import six
import os
from urllib.parse import urlparse, parse_qs, quote_plus
import time
import sys
import threading
from lib.images import background_image_path, anterior_normal, anterior_hover, proximo_normal, proximo_hover, tela_normal, tela_hover

addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
homeDir = addon.getAddonInfo('path')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
addonIcon = translate(os.path.join(homeDir, 'icon.png'))
kversion = int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0])


def log(txt):
    try:
        message = ''.join([addonName, ' : ', txt])
        xbmc.log(msg=message, level=xbmc.LOGDEBUG)
    except:
        pass


def painel_vod1(search=None, mode='series'):
    global CACHE
    global search_
    global page
    global mode_
    global next_page
    mode_ = mode
    search_ = search
    page = 1
    next_page = False
    CACHE = []
    window = Vod1interfaceSeries('spartan')
    window.doModal()     

def fechar_janela(self):
    xbmc.executebuiltin("Container.Update(path,replace)")
    self.close()
    try:
        sys.exit()
    except:
        pass


def stream_serie(name,link_,iconimage,desc):
    if acesso.access():
        try:
            stream, sub = resolverlib.Resolver().resolverurls(link_,'')
            if stream:
                liz = xbmcgui.ListItem(name)
                if kversion > 19:
                    info = liz.getVideoInfoTag()
                    info.setTitle(name)
                    info.setPlot(desc)
                    #info.setGenres([str(genre)])
                    #info.setYear(int(year))
                else:
                    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": desc}) 
                    #liz.setInfo('video', {'genre': str(genre)}) 
                    #liz.setInfo('video', {'year': int(year)})      
                liz.setArt({"thumb": iconimage, "icon": iconimage})
                liz.setProperty('IsPlayable', 'true')
                liz.setPath(stream)
                if sub:
                    liz.setSubtitles([sub])                 
                xbmc.Player().play(stream, liz, False)
                try:
                    quit()
                except:
                    pass
            else:
                xbmcgui.Dialog().notification("Info", "Sem Stream disponivel", xbmcgui.NOTIFICATION_INFO, sound=False)
        except:
            xbmcgui.Dialog().notification("Info", "Não foi possivel reproduzir", xbmcgui.NOTIFICATION_INFO, sound=False)
    else:
        xbmcgui.Dialog().notification("Erro", "Acesso Negado, tente denovo ou verifique sua conexão", xbmcgui.NOTIFICATION_ERROR)                    





def TEMPORADAS(name,link,iconimage,desc):
    if acesso.access():
        xbmcgui.Dialog().notification("Info", "Aguarde!", xbmcgui.NOTIFICATION_INFO, sound=False)
        temp = scrape_vod.filmes_op1().temporadas(link)
        if temp:
            seasons = [('TEMPORADA %s'%s, s) for s in temp]
            op = xbmcgui.Dialog().select(name.upper(), [s[0] for s in seasons])
            if op >= 0:
                s_ = str(seasons[op][1])
                eps = scrape_vod.filmes_op1().episodios(s_,link)
                if eps:
                    episodes = [('Episódio %s'%e, e, link) for e, link in eps]
                    op = xbmcgui.Dialog().select('Selecione um episódio', [e[0] for e in episodes])
                    if op >=0:
                        e_ = str(episodes[op][1])
                        page_stream = str(episodes[op][2])
                        name_stream = name + ' - ' + s_ + 'x' + e_
                        stream_serie(name_stream,page_stream,iconimage,desc)
                else:
                    xbmcgui.Dialog().notification("Info", "Sem episódios disponivel", xbmcgui.NOTIFICATION_INFO, sound=False)

        else:
            xbmcgui.Dialog().notification("Info", "Sem temporadas disponiveis", xbmcgui.NOTIFICATION_INFO, sound=False)                    
    else:
        xbmcgui.Dialog().notification("Erro", "Acesso Negado, tente denovo ou verifique sua conexão", xbmcgui.NOTIFICATION_ERROR)         






def LISTA_SERIES(self, carrega=True):
    global CACHE
    global mode_
    global next_page
    global page
    global itens_
    global search_
    if carrega:
        xbmcgui.Dialog().notification("Info", "Aguarde!", xbmcgui.NOTIFICATION_INFO, sound=False)
        if mode_ == 'series':
            if page == 1:
                next_page = False
                CACHE = []         
            itens, next_page, page_ = scrape_vod.filmes_op1().catalogo_series(next_page)
            new_itens = [{'name': name, 'description': '', 'iconimage': img, 'url': link} for name,link,img in itens]
            i = {page: new_itens}
            if itens and len(CACHE) < page:
                CACHE.append(i)
        elif mode_ == 'pesquisa':
            if next_page:
                pesquisa = False
            else:
                pesquisa = search_
            if page == 1:
                CACHE = []                  
            itens, next_page, page_ = scrape_vod.filmes_op1().pesquisa_conteudo(next_page,pesquisa)
            new_itens = [{'name': name, 'description': '', 'iconimage': img, 'url': link} for name,link,img,t in itens if t == 'tvshow']
            i = {page: new_itens}
            if itens and len(CACHE) < page:
                CACHE.append(i)            

    if CACHE:
        itens_ = CACHE[page-1][page]
        self.LIST_SERIES.reset()
        for i in itens_:
            self.LIST_SERIES.addItem('[B]%s[/B]' % i['name'])
    else:
        itens_ = []
        xbmcgui.Dialog().notification("Info", "Nenhuma série encontrada", xbmcgui.NOTIFICATION_INFO, sound=False)
        fechar_janela(self)
    if page > 1:
        self.update_anterior_button(True)
    else:
        self.update_anterior_button(False)
    if next_page or page == 1:
        self.update_proximo_button(True)
    else:
        self.update_proximo_button(False)
           

    
def PROXIMA_PAGINA(self):
    global CACHE
    global mode_
    global next_page
    global page
    global itens_   
    if next_page or page == 1:
        page += 1
        LISTA_SERIES(self, carrega=True)

def PAGINA_ANTERIOR(self):
    global CACHE
    global mode_
    global next_page
    global page
    global itens_  
    if page > 1:
        page -= 1
        LISTA_SERIES(self, carrega=False)
    else:
        self.update_anterior_button(False)



def clock(self):
    time2 = time.strftime("%I:%M %p")
    self.TIME.setLabel(str(time2))  

class Vod1interfaceSeries(pyxbmct.AddonFullWindow):
    def __init__(self, title="spartan"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.connect(pyxbmct.ACTION_NAV_BACK, lambda: fechar_janela(self))
        self.set_list_controls()
        self.botao_anterior()
        self.botao_proximo()
        self.voltar_tela()      
        LISTA_SERIES(self)
        self.setFocus(self.LIST_SERIES)
        self.logo_serie()
        self.update_logo()
        self.set_navigation()
                         

    def set_list_controls(self):
        self.category_name = pyxbmct.Label("Séries:", textColor="0xFFFFFF00", font='font18')
        self.placeControl(self.category_name, 22, 9, 80, 18)     
        self.LIST_SERIES = pyxbmct.List()
        self.placeControl(self.LIST_SERIES, 30, 2, 80, 17)
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.update_list_series)      
        self.connect(self.LIST_SERIES, lambda: TEMPORADAS(name,stream_page,logo_image,descrition))        

    def update_list_series(self):
        global itens_
        global stream_page
        global descrition
        global name
        global logo_image
        descrition = ''
        try:
            if self.getFocus() == self.LIST_SERIES:
                position_list1 = self.LIST_SERIES.getSelectedPosition()
                logo_image = itens_[position_list1]['iconimage']
                name = itens_[position_list1]['name']
                stream_page = itens_[position_list1]['url']
                self.logo.setImage(logo_image)
        except (RuntimeError, SystemError):
            pass       

    def update_logo(self):
        """Atualiza o logo quando a lista é carregada."""
        if len(itens_) > 0:
            self.logo.setImage(itens_[0]['iconimage'])    

    def logo_serie(self):
        #self.logo_name = pyxbmct.Label("Logo:", textColor="0xFFFFFF00", font='font18')
        # self.placeControl(self.logo_name, 22, 36, 80, 18) 
        self.logo = pyxbmct.Image('')
        self.placeControl(self.logo, 30, 19, 75, 9)                  

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.addControl(self.main_bg)

    def update_anterior_button(self, enabled):
        self.anterior_button.setEnabled(enabled)

    def update_proximo_button(self, enabled):
        self.proximo_button.setEnabled(enabled)

    def botao_anterior(self):
        self.anterior_button = pyxbmct.Button("", focusTexture=anterior_hover, noFocusTexture=anterior_normal)
        self.placeControl(self.anterior_button, 105, 17, 24, 7)
        self.connect(self.anterior_button, lambda: PAGINA_ANTERIOR(self))

    def botao_proximo(self):
        self.proximo_button = pyxbmct.Button("", focusTexture=proximo_hover, noFocusTexture=proximo_normal)
        self.placeControl(self.proximo_button, 105, 27, 24, 7)
        self.connect(self.proximo_button, lambda: PROXIMA_PAGINA(self))

    def voltar_tela(self):
        self.tela_button = pyxbmct.Button("", focusTexture=tela_hover, noFocusTexture=tela_normal)
        self.placeControl(self.tela_button, 125, 22, 24, 7)
        self.connect(self.tela_button, lambda: fechar_janela(self))        


    def set_navigation(self):
        self.LIST_SERIES.controlDown(self.proximo_button)
        self.proximo_button.controlUp(self.LIST_SERIES)
        self.proximo_button.controlLeft(self.anterior_button)
        self.anterior_button.controlRight(self.proximo_button)        
        self.anterior_button.controlUp(self.LIST_SERIES)
        self.anterior_button.controlDown(self.tela_button)
        self.proximo_button.controlDown(self.tela_button)
        self.tela_button.controlUp(self.proximo_button)
