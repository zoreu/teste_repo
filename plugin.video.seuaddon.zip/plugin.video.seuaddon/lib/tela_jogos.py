try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except ImportError:
    import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
import pyxbmct.addonwindow as pyxbmct
from lib import acesso, addon, jogos, dns_proxy
import six
import os
from urllib.parse import urlparse, parse_qs, quote_plus
import time
import sys
import threading
from lib.images import background_image_path, voltar_normal, voltar_hover

addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
homeDir = addon.getAddonInfo('path')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
addonIcon = translate(os.path.join(homeDir, 'icon.png'))
kversion = int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0])


def log(txt):
    try:
        message = ''.join([addonName, ' : ', txt])
        xbmc.log(msg=message, level=xbmc.LOGDEBUG)
    except:
        pass


def jogos_window():
    global media_item
    xbmcgui.Dialog().notification("Info", "Aguarde!", xbmcgui.NOTIFICATION_INFO)
    media_item = jogos.catalogo_jogos()
    if media_item:        
        window = JogosInterface('Spartan_jogos')
        window.doModal()
        del window
    else:
        dialog = xbmcgui.Dialog()
        ok = dialog.ok('Aviso', 'Por favor troque dns ou use vpn para conectar')    

def fechar_janela(self):
    xbmc.executebuiltin("Container.Update(path,replace)")
    self.close()
    try:
        sys.exit()
    except:
        pass



def Player(name, streams):
    if acesso.access():
        pages = streams
        if pages:
            names = ['OPÇÃO %s'%str(number + 1) for number, i in enumerate(pages)]
            op = xbmcgui.Dialog().select('SELECIONE UMA OPÇÃO', names)
            if op >= 0:
                page = pages[op]
                xbmcgui.Dialog().notification("Info", "Aguarde!", xbmcgui.NOTIFICATION_INFO)
                try:
                    if not 'youtube' in page:
                        stream = jogos.get_stream(page)               
                        proxy_url = dns_proxy.url_proxy + quote_plus(stream)
                        dns_proxy.DNSProxyManager().start()
                    else:
                        proxy_url = jogos.get_stream(page)                   
                    liz = xbmcgui.ListItem(name)
                    if kversion > 19:
                        info = liz.getVideoInfoTag()
                        info.setTitle(name)
                        info.setPlot("")
                    else:
                        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": ""})        
                    liz.setArt({"thumb": addonIcon})
                    liz.setProperty('IsPlayable', 'true')
                    liz.setPath(proxy_url)
                
                    xbmc.Player().play(proxy_url, liz, False)
                    quit()
                except:
                    pass
    else:
        xbmcgui.Dialog().notification("Erro", "Acesso Negado, tente denovo ou verifique sua conexão", xbmcgui.NOTIFICATION_ERROR)  

def menu_items(self):
    global media_item
    for i in media_item:
        self.list.addItem('[B]%s[/B]' % i['name'])

def clock(self):
    time2 = time.strftime("%I:%M %p")
    self.TIME.setLabel(str(time2))  

             

class JogosInterface(pyxbmct.AddonFullWindow):
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    def __init__(self, title="Jogos"):
        super().__init__(title)
        self.setGeometry(1280, 720, 150, 50)
        self.set_background_image()
        self.connect(pyxbmct.ACTION_NAV_BACK, lambda: fechar_janela(self))
        self.set_list_controls()
        menu_items(self)
        self.setFocus(self.list)
        self.connect(self.list, lambda: Player(name,streams))
        self.set_opcao()
        self.botao_voltar()
        self.set_navigation()
        #self.relogio()

    def update_relogio(self):
        clock(self)        

    def relogio(self):
        self.TIME = pyxbmct.Label('',textColor='0xFFFFFFFF', font='font14')
        self.placeControl(self.TIME, 1,42, 12, 10)
        time2 = time.strftime("%I:%M %p")
        self.TIME.setLabel(str(time2))
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
            pyxbmct.ACTION_MOVE_UP,
            pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
            pyxbmct.ACTION_MOUSE_WHEEL_UP,
            pyxbmct.ACTION_MOUSE_MOVE],
            self.update_relogio)                 

    # def update_logo(self):
    #     """Atualiza o logo quando a lista é carregada."""
    #     if len(media_item) > 0:
    #         self.equipe1_logo.setImage(media_item[0]['equipe1_logo'])
    #         self.equipe2_logo.setImage(media_item[0]['equipe2_logo'])

    def set_opcao(self):
        global media_item
        global name
        global streams 
        """Atualiza o logo quando a lista é carregada."""
        if len(media_item) > 0:
            try:
                # Atualiza a primeira opção da lista ao carregar
                self.list.selectItem(0)
                #self.update_list()
                try:
                    position = self.list.getSelectedPosition()
                    item = media_item[position]
                    name = item['name']
                    streams = item['streams']
                    self.equipe1_logo.setImage(item['equipe1_logo'])
                    self.equipe2_logo.setImage(item['equipe2_logo'])
                except:
                    pass                    
            except (RuntimeError, SystemError):
                pass     

    def update_list(self):
        global media_item
        global name
        global streams
        try:
            if self.getFocus() == self.list:
                position = self.list.getSelectedPosition()
                item = media_item[position]
                name = item['name']
                streams = item['streams']
                self.equipe1_logo.setImage(item['equipe1_logo'])
                self.equipe2_logo.setImage(item['equipe2_logo'])
        except (RuntimeError, SystemError):
            pass

    def set_list_controls(self):
        self.name_jogos = pyxbmct.Label("JOGOS DE HOJE", textColor="0xFFFFFF00", font='font40')
        self.placeControl(self.name_jogos, 6, 22, 15, 28)
        self.list = pyxbmct.List()
        self.placeControl(self.list, 19, 20, 94, 25)
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.update_list)
        self.equipe1_logo = pyxbmct.Image('')
        self.placeControl(self.equipe1_logo, 19, 10, 15, 4)
        self.versus = pyxbmct.Label("X", textColor="0xFFFFFF00", font='font40')
        self.placeControl(self.versus, 19, 14, 15, 28)
        self.equipe2_logo = pyxbmct.Image('')
        self.placeControl(self.equipe2_logo, 19, 15, 15, 4)

    def set_background_image(self):
        """Define uma imagem de fundo para a janela."""
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, background_image_path)
        self.main_bg.setImage(background_image_path)
        self.addControl(self.main_bg)

    def botao_voltar(self):
        self.voltar_button = pyxbmct.Button("", focusTexture=voltar_hover, noFocusTexture=voltar_normal)
        self.placeControl(self.voltar_button, 113, 22, 24, 7)
        self.connect(self.voltar_button, lambda: fechar_janela(self))

    def set_navigation(self):
        self.list.controlDown(self.voltar_button)
        self.voltar_button.controlUp(self.list)    


