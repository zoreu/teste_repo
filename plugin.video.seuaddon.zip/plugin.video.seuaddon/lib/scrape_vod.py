try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
try:
    from lib import dns
except ImportError:
    import dns
try:
    from lib.dns import CloudflareHTTP
except:
    from dns import CloudflareHTTP

try:
    from lib import jsunpack
except:
    import jsunpack
from bs4 import BeautifulSoup
import re
import requests
import json

headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0'}

search_filmes_op1 = 'https://comandoplay.com/?s='
referer_filmes_op1 = 'https://comandoplay.com/'
site_filmes_op1 = 'https://comandoplay.com/category/movies-2/'
site_series_op1 = 'https://comandoplay.com/category/tv-series/'
site_pesquisa_doramas = 'https://doramasonline.org/?s='
site_doramas_filmes = 'https://doramasonline.org/br/filmes/'
site_doramas_dublados = 'https://doramasonline.org/br/generos/dublado/'
site_doramas_legendados = 'https://doramasonline.org/br/generos/legendado/'
site_novelas = 'https://noveflix.zip/categoria/novelas/'
referer_novelas = 'https://noveflix.zip/'


class filmes_op1:
    def soup(self,src):
        soup = BeautifulSoup(src,'html.parser')
        return soup
    
    def get_packed_data(self,html):
        packed_data = ''
        try:
            for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
                r = match.group(1)
                t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
                if len(t) == 1:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
                else:
                    t = r.split('eval')
                    t = ['eval' + x for x in t if x]
                    for r in t:
                        if jsunpack.detect(r):
                            packed_data += jsunpack.unpack(r)
        except:
            pass
        return packed_data
    
    def pesquisa_conteudo(self,url=None,pesquisa=None):
        itens = []
        next = False
        page = ''
        if pesquisa:
            url = search_filmes_op1 + quote_plus(pesquisa)
        if url:
            try:
                headers.update({'Referer': referer_filmes_op1})
                r = requests.get(url,headers=headers)
                src = r.text
                soup = self.soup(src)
                container = soup.find('section', {'id': 'content'}).find('div', {'class': 'item-container'})
                posts = container.find_all("div", id=lambda x: x and x.startswith("post"))
                for i in posts:
                    img = i.find('img').get('data-src', '')
                    img = img.replace('w220_and_h330_face', 'w600_and_h900_bestv2')
                    name = i.find('h2', {'class': 'movie-title'}).text.strip()
                    try:
                        year = i.find('span', {'class': 'movie-date'}).text.strip()
                    except:
                        year = ''
                    try:
                        t = i.find('div', {'class': 'item-flip'}).find('span', {'class': 'item-tv'}).text
                        if t.lower() == 'tv':
                            t = 'tvshow'
                        else:
                            t = 'movie'
                    except:
                        t = 'movie'
                        
                    link = i.find('a').get('href', '')
                    try:
                        name = name.decode('utf-8')
                    except:
                        pass                    
                    if year:
                        name = name + ' (' + year + ')'
                    # set name to kodi
                    #name = '[B]' + name + '[/B]'
                    itens.append((name,link,img,t))
                try:
                    pagination = soup.find('div', {'class': 'pagination'})
                    current = soup.find('span', {'class': 'current'}).text.strip()
                    try:
                        next_ = pagination.find_all('a', {'class': 'next arrow_pag'})[-1].get('href', '')
                        if next_:
                            try:
                                page = next_.split('/page/')[1]
                            except:
                                page = ''
                            try:
                                page = page.split('/')[0]
                            except:
                                pass
                            try:
                                page = page.split('?')[0]
                            except:
                                pass
                            if int(page) > int(current):
                                next = next_
                    except:
                        try:
                            next_ = pagination.find_all('a', {'class': 'inactive'})[-1].get('href', '')
                            if next_:
                                try:
                                    page = next_.split('/page/')[1]
                                except:
                                    page = ''
                                try:
                                    page = page.split('/')[0]
                                except:
                                    pass
                            try:
                                page = page.split('?')[0]
                            except:
                                pass
                            p_base = page
                            if int(page) > int(current):
                                next = next_
                                p = int(page)
                                while True:                                
                                    if p > int(current):
                                        p = p - 1
                                    if p == int(current):
                                        p +=1
                                        break
                                next = next_.replace(p_base, str(p))
                                page = p
                        except:
                            pass

                except:
                    pass
            except:
                pass
        return itens, next, page  
            
    def catalogo_filmes(self,url=False):
        if not url:
            url = site_filmes_op1
        itens = []
        next = False
        page = ''
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            container = soup.find('section', {'id': 'content'}).find('div', {'class': 'item-container'})
            posts = container.find_all("div", id=lambda x: x and x.startswith("post"))
            for i in posts:
                img = i.find('img').get('data-src', '')
                img = img.replace('w220_and_h330_face', 'w600_and_h900_bestv2')
                name = i.find('h2', {'class': 'movie-title'}).text.strip()
                try:
                    year = i.find('span', {'class': 'movie-date'}).text.strip()
                except:
                    year = ''
                link = i.find('a').get('href', '')
                try:
                    name = name.decode('utf-8')
                except:
                    pass                    
                if year:
                    name = name + ' (' + year + ')'
                # set name to kodi
                #name = '[B]' + name + '[/B]'
                itens.append((name,link,img))
            try:
                pagination = soup.find('div', {'class': 'pagination'})
                current = soup.find('span', {'class': 'current'}).text.strip()
                try:
                    next_ = pagination.find_all('a', {'class': 'next arrow_pag'})[-1].get('href', '')
                    if next_:
                        try:
                            page = next_.split('/page/')[1]
                        except:
                            page = ''
                        try:
                            page = page.split('/')[0]
                        except:
                            pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        if int(page) > int(current):
                            next = next_
                except:
                    try:
                        next_ = pagination.find_all('a', {'class': 'inactive'})[-1].get('href', '')
                        if next_:
                            try:
                                page = next_.split('/page/')[1]
                            except:
                                page = ''
                            try:
                                page = page.split('/')[0]
                            except:
                                pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        p_base = page
                        if int(page) > int(current):
                            next = next_
                            p = int(page)
                            while True:                                
                                if p > int(current):
                                    p = p - 1
                                if p == int(current):
                                    p +=1
                                    break
                            next = next_.replace(p_base, str(p))
                            page = p
                    except:
                        pass

            except:
                pass
        except:
            pass
        return itens, next, page
    
    def catalogo_series(self,url=False):
        if not url:
            url = site_series_op1
        itens = []
        next = False
        page = ''
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            container = soup.find('section', {'id': 'content'}).find('div', {'class': 'item-container'})
            posts = container.find_all("div", id=lambda x: x and x.startswith("post"))
            for i in posts:
                img = i.find('img').get('data-src', '')
                img = img.replace('w220_and_h330_face', 'w600_and_h900_bestv2')
                name = i.find('h2', {'class': 'movie-title'}).text.strip()
                try:
                    year = i.find('span', {'class': 'movie-date'}).text.strip()
                except:
                    year = ''
                link = i.find('a').get('href', '')
                try:
                    name = name.decode('utf-8')
                except:
                    pass                    
                if year:
                    name = name + ' (' + year + ')'
                # set name to kodi
                #name = '[B]' + name + '[/B]'
                itens.append((name,link,img))
            try:
                pagination = soup.find('div', {'class': 'pagination'})
                current = soup.find('span', {'class': 'current'}).text.strip()
                try:
                    next_ = pagination.find_all('a', {'class': 'next arrow_pag'})[-1].get('href', '')
                    if next_:
                        try:
                            page = next_.split('/page/')[1]
                        except:
                            page = ''
                        try:
                            page = page.split('/')[0]
                        except:
                            pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        if int(page) > int(current):
                            next = next_
                except:
                    try:
                        next_ = pagination.find_all('a', {'class': 'inactive'})[-1].get('href', '')
                        if next_:
                            try:
                                page = next_.split('/page/')[1]
                            except:
                                page = ''
                            try:
                                page = page.split('/')[0]
                            except:
                                pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        p_base = page
                        if int(page) > int(current):
                            next = next_
                            p = int(page)
                            while True:                                
                                if p > int(current):
                                    p = p - 1
                                if p == int(current):
                                    p +=1
                                    break
                            next = next_.replace(p_base, str(p))
                            page = p
                    except:
                        pass

            except:
                pass
        except:
            pass
        return itens, next, page    
    
    def temporadas(self,url):
        seasons = []
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            streaming = json.loads(re.findall(r'var streaming = (.*?);', src)[0])
            for i in streaming.keys():
                season = re.findall(r's(.*?)_', i)[0]
                if not season in seasons:
                    seasons.append((season))            
        except:
            pass
        return seasons 

    def episodios(self,season,url):
        itens = []
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            streaming = json.loads(re.findall(r'var streaming = (.*?);', src)[0])
            for i in streaming.keys():
                season_ = re.findall(r's(.*?)_', i)[0]
                episode_ = re.findall(r'_(.*)', i)[0]
                if season == season_:
                    link = streaming.get(i)
                    itens.append((episode_,link))          
        except:
            pass
        return itens            

    def opcoes_link(self,url):
        opcoes = []
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            a = soup.find_all('a', {'rel': 'modal'})
            if a:
                n = 0
                for i in a:
                    link = i.get('href', '')
                    if 'br' in link or 'wish' in link or 'streamtape' in link:
                        n += 1
                        name = 'PLAYER %s'%str(n)
                        opcoes.append((name,link,url))

        except:
            pass
        return opcoes 

class filmes_op2:
    def __init__(self):
        self.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0'}        
        self.base = self.get_last_base()


    def get_last_base(self):
        host_base = 'https://netcine.mov'
        last_url = ''
        try:
            r = requests.get(host_base,headers=self.headers,timeout=4)
            last_url = r.url
        except:
            pass     

        if last_url and last_url.endswith('/'):
            last_url = last_url[:-1]
        return last_url

    def soup(self,src):
        soup = BeautifulSoup(src,'html.parser')
        return soup
    
    def get_packed_data(self,html):
        packed_data = ''
        try:
            for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
                r = match.group(1)
                t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
                if len(t) == 1:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
                else:
                    t = r.split('eval')
                    t = ['eval' + x for x in t if x]
                    for r in t:
                        if jsunpack.detect(r):
                            packed_data += jsunpack.unpack(r)
        except:
            pass
        return packed_data

    def pesquisa_filmes(self,url,pesquisa):
        itens_pesquisa = []
        next_page = False
        page = ''
        if pesquisa:
            url = '%s/?s=%s'%(self.base,quote_plus(pesquisa))           
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')
                if 'hdcam' in link and not 'hdcam' in name.lower():
                    name = '%s (HDCAM)'%name
                if year:
                    name = '%s (%s)'%(name,str(year))              
                itens_pesquisa.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return itens_pesquisa, next_page, page 

    def scraper_filmes(self, url=''):
        if not url:
            url = self.base + '/category/ultimos-filmes/'
        filmes = []
        next_page = False
        page = ''
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')                
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                if year:
                    if 'hdcam' in link and not 'hdcam' in name.lower():
                        name = '%s (%s) (HDCAM)'%(name,str(year))
                    else:
                        name = '%s (%s)'%(name,str(year))
                else:
                    if 'hdcam' in link and not 'hdcam' in name.lower():
                        name = '%s (HDCAM)'%name
                filmes.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return filmes, next_page, page

    def opcoes_filmes(self,url):
        opcoes = []      
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            player = soup.find('div', {'id': 'player-container'})
            botoes = player.find('ul', {'class': 'player-menu'})
            op = botoes.findAll('li')
            op_list = []
            if op:
                for i in op:
                    a = i.find('a')
                    id_ = a.get('href', '').replace('#', '')
                    op_name = a.text
                    try:
                        op_name = op_name.decode('utf-8')
                    except:
                        pass
                    op_name = op_name.replace(' 1', '').replace(' 2', '').replace(' 3', '').replace(' 4', '').replace(' 5', '')
                    op_name = op_name.strip()
                    op_name = op_name.upper()
                    op_list.append((op_name,id_))
            if op_list:
                for name, id_ in op_list:
                    iframe = player.find('div', {'class': 'play-c'}).find('div', {'id': id_}).find('iframe').get('src', '')
                    if not 'streamtape' in iframe:
                        link = self.base + '/' + iframe
                    else:
                        link = iframe
                    opcoes.append((name,link))

        except:
            pass
        return opcoes

    def scraper_series(self, url=''):
        if not url:
            url = self.base + '/tvshows/'          
        series = []
        next_page = False
        page = ''
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                if year:
                    name = '%s (%s)'%(name,str(year))
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')
                series.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return series, next_page, page

    def scraper_temporadas_series(self,url):
        url_original = url       
        list_seasons = []
        serie_name_final = ''
        img = ''
        fanart = ''        
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url, headers=headers_)
            src = r.text
            soup = self.soup(src)
            # info
            try:
                div_img = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'class': 'headingder'})
                fanart = div_img.find('div', class_=lambda x: x and 'lazyload' in x).get('data-bg', '')
                img = div_img.find('img', {'class': 'lazyload'}).get('data-src', '')
                try:
                    serie_name = div_img.find('div', {'class': 'datos'}).find('div', {'class': 'dataplus'}).find('h1').text
                    try:
                        serie_name = serie_name.decode('utf-8')
                    except:
                        pass
                    #serie_name_final = '[B]:::: SÉRIE: %s ::::[/B]'%serie_name
                    serie_name_final = serie_name
                except:
                    pass
            except:
                pass
            s = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'id': 'cssmenu'}).find('ul').findAll('li', {'class': 'has-sub'})
            for n, i in enumerate(s):
                n += 1
                name = 'TEMPORADA %s'%str(n)
                season = str(n)
                list_seasons.append((season,name,url_original))
        except:
            pass
        return serie_name_final, img, fanart, list_seasons 

    def scraper_episodios_series(self,url,season):
        list_episodes = []
        serie_name_final = ''
        img = ''
        fanart = ''        
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url, headers=headers_)
            src = r.text
            soup = self.soup(src)
            # info
            try:
                div_img = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'class': 'headingder'})
                fanart = div_img.find('div', class_=lambda x: x and 'lazyload' in x).get('data-bg', '')
                img = div_img.find('img', {'class': 'lazyload'}).get('data-src', '')
                try:
                    serie_name = div_img.find('div', {'class': 'datos'}).find('div', {'class': 'dataplus'}).find('h1').text
                    try:
                        serie_name = serie_name.decode('utf-8')
                    except:
                        pass
                    #serie_name_final = '[B]:::: SÉRIE: %s ::::[/B]'%serie_name
                    serie_name_final = serie_name
                except:
                    pass
            except:
                pass
            s = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'id': 'cssmenu'}).find('ul').findAll('li', {'class': 'has-sub'})
            for n, i in enumerate(s):
                n += 1
                if int(season) == n:
                    e = i.find('ul').findAll('li')
                    for n, i in enumerate(e):
                        n += 1
                        e_info = i.find('a')
                        link = e_info.get('href')
                        ep_name = e_info.find('span', {'class': 'datix'}).text
                        try:
                            ep_name = ep_name.decode('utf-8')
                        except:
                            pass
                        ep_name = ep_name.strip()
                        name_especial = '%s - %s x %s - %s'%(serie_name,str(season),str(n),ep_name)
                        ep_name2 = '%s - %s'%(str(n),ep_name)
                        list_episodes.append((ep_name2,name_especial,link))
                    break
        except:
            pass
        return serie_name_final, img, fanart, list_episodes

class Doramas:
    def soup(self,src):
        soup = BeautifulSoup(src,'html.parser')
        return soup

    def doramas_pesquisa(self,url=None,pesquisa=None):
        itens = []
        next = False
        page = ''
        if pesquisa:
            url = site_pesquisa_doramas + quote_plus(pesquisa)
        if url:           
            try:
                headers.update({'Accept-Language': 'pt-BR', 'Referer': 'https://doramasonline.org/'})
                r = requests.get(url,headers=headers)
                src = r.text
                soup = self.soup(src)
                try:
                    d = soup.find_all("div", {"class": "result-item"})
                    if d:
                        for dorama in d:
                            img = dorama.find('div', {'class': 'image'}).find('img').get('src', '')
                            img = img.replace('/w92/', '/w600_and_h900_bestv2/')
                            href = dorama.find('div', {'class': 'image'}).find('a').get('href', '')
                            t = dorama.find('div', {'class': 'image'}).find_all('span')[0].get('class', '')[-1]
                            name = dorama.find('div', {'class': 'title'}).find('a').text
                            try:
                                name = name.decode('utf-8')
                            except:
                                pass
                            #name = '[B]' + name + '[/B]'
                            itens.append((name,href,img,t))
                except:
                    pass
                try:
                    next_ = soup.find('div', {'class':'pagination'}).find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                    current = soup.find('div', {'class':'pagination'}).find('span', {'class': 'current'}).text
                    if next_:
                        try:
                            page = next_.split('/page/')[1]
                        except:
                            page = ''
                        try:
                            page = page.split('/')[0]
                        except:
                            pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        if int(page) > int(current):
                            next = next_
                except:
                    pass                   
            except:
                pass
        return itens, next, page

    # dorams filmes
    def doramas_filmes(self,url=False):
        if not url:
            url = site_doramas_filmes
        itens = []
        next = False
        page = ''
        try:
            headers.update({'Accept-Language': 'pt-BR', 'Referer': 'https://doramasonline.org/'})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            try:
                d = soup.find('div', {'id': 'archive-content'}).find_all("article", id=lambda x: x and x.startswith("post"))
                if d:
                    for dorama in d:
                        href = dorama.find('a').get('href', '')
                        name = dorama.find('h3').find('a').text
                        try:
                            name = name.decode('utf-8')
                        except:
                            pass
                        #name = '[B]' + name + '[/B]'
                        img = dorama.find('img').get('src', '')
                        img = img.replace('/w185/', '/w600_and_h900_bestv2/')
                        itens.append((name,href,img))
            except:
                pass
            try:
                next_ = soup.find('div', {'class':'pagination'}).find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                current = soup.find('div', {'class':'pagination'}).find('span', {'class': 'current'}).text
                if next_:
                    try:
                        page = next_.split('/page/')[1]
                    except:
                        page = ''
                    try:
                        page = page.split('/')[0]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass
                    if int(page) > int(current):
                        next = next_
            except:
                pass            

        except:
            pass
        return itens, next, page



    
    def doramas_dublado(self,url=False):
        if not url:
            url = site_doramas_dublados
        itens = []
        next = False
        page = ''
        try:
            headers.update({'Accept-Language': 'pt-BR', 'Referer': 'https://doramasonline.org/'})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            try:
                d = soup.find("div", class_=lambda x: x and x.startswith("items")).find_all("article", id=lambda x: x and x.startswith("post"))
                if d:
                    for dorama in d:
                        t = dorama.get('class', '')[-1]
                        href = dorama.find('a').get('href', '')
                        name = dorama.find('h3').find('a').text
                        try:
                            name = name.decode('utf-8')
                        except:
                            pass
                        #name = '[B]' + name + '[/B]'
                        img = dorama.find('img').get('src', '')
                        img = img.replace('/w185/', '/w600_and_h900_bestv2/')
                        itens.append((name,href,img,t))
            except:
                pass
            try:
                next_ = soup.find('div', {'class':'pagination'}).find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                current = soup.find('div', {'class':'pagination'}).find('span', {'class': 'current'}).text
                if next_:
                    try:
                        page = next_.split('/page/')[1]
                    except:
                        page = ''
                    try:
                        page = page.split('/')[0]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass
                    if int(page) > int(current):
                        next = next_
            except:
                pass
        except:
            pass 
        return itens, next, page
    
    def doramas_legendado(self,url=False):
        if not url:
            url = site_doramas_legendados
        itens = []
        next = False
        page = ''
        try:
            headers.update({'Accept-Language': 'pt-BR', 'Referer': 'https://doramasonline.org/'})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            try:
                d = soup.find("div", class_=lambda x: x and x.startswith("items")).find_all("article", id=lambda x: x and x.startswith("post"))
                if d:
                    for dorama in d:
                        t = dorama.get('class', '')[-1]
                        href = dorama.find('a').get('href', '')
                        name = dorama.find('h3').find('a').text
                        try:
                            name = name.decode('utf-8')
                        except:
                            pass
                        #name = '[B]' + name + '[/B]'
                        img = dorama.find('img').get('src', '')
                        img = img.replace('/w185/', '/w600_and_h900_bestv2/')
                        itens.append((name,href,img,t))
            except:
                pass
            try:
                next_ = soup.find('div', {'class':'pagination'}).find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                current = soup.find('div', {'class':'pagination'}).find('span', {'class': 'current'}).text
                if next_:
                    try:
                        page = next_.split('/page/')[1]
                    except:
                        page = ''
                    try:
                        page = page.split('/')[0]
                    except:
                        pass
                    try:
                        page = page.split('?')[0]
                    except:
                        pass
                    if int(page) > int(current):
                        next = next_
            except:
                pass
        except:
            pass 
        return itens, next, page    
    
    def temporadas(self,url):
        list_seasons = []
        try:
            headers.update({'Accept-Language': 'pt-BR', 'Referer': 'https://doramasonline.org/'})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            s = soup.find('div', {'id': 'serie_contenido'}).find('div', {'id': 'seasons'}).find_all('div', {'class': 'se-c'})
            for n, i in enumerate(s):
                n += 1
                name = 'Temporada %s'%str(n)
                season = str(n)
                list_seasons.append((season,name,url))
        except:
            pass
        return list_seasons
    
    def episodios(self,url,season):
        list_episodes = []
        try:
            headers.update({'Accept-Language': 'pt-BR', 'Referer': 'https://doramasonline.org/'})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            s = soup.find('div', {'id': 'serie_contenido'}).find('div', {'id': 'seasons'}).find_all('div', {'class': 'se-c'})
            for n, i in enumerate(s):
                n += 1
                if int(season) == n:
                    e = i.find('div', {'class': 'se-a'}).find('ul').find_all('li')
                    for n, i in enumerate(e):
                        n += 1
                        img = i.find('div',{'class': 'imagen'}).find('img').get('src', '')
                        img = img.replace('/w154/', '/w600_and_h900_bestv2/')
                        a = i.find('div', {'class': 'episodiotitle'}).find('a')
                        try:
                            name_episode = a.text
                            try:
                                name_episode = name_episode.decode('utf-8')
                            except:
                                pass
                        except:
                            name_episode = 'Episódio %s'%str(n)
                        #name_episode = '[B]' + name_episode + '[/B]'
                        href = a.get('href', '')
                        list_episodes.append((name_episode,img,href))
        except:
            pass
        return list_episodes   
    
    def opcoes_link(self,url):
        opcoes = []
        try:
            headers.update({'Referer': 'https://doramasonline.org/'})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            names = []
            #<li id='player-option-1' class='dooplay_player_option' data-type='tv' data-post='42951' data-nume='1'><i class='fas fa-play-circle'></i><span class='title'>DUBLADO</span><span class='loader'></span></li>
            try:
                lis = soup.find_all('li', {'class': 'dooplay_player_option'})
                for li in lis:
                    name = li.find('span', {'class': 'title'}).text
                    names.append(name)
            except:
                pass
            iframes = soup.find_all("iframe", class_=lambda x: x and x.startswith("metaframe"))
            if iframes:
                if len(names) == len(iframes):
                    mode = 1
                else:
                    mode = 2
                for n, i in enumerate(iframes):
                    if mode == 1:
                        name = names[n]
                    else:
                        n += 1
                        name = 'Opção %s'%str(n)
                    link = i.get('src', '')
                    opcoes.append((name,link))

        except:
            pass
        return opcoes

class Novelas:
    def soup(self,src):
        soup = BeautifulSoup(src,'html.parser')
        return soup
    
    def append_headers(self,headers):
        return '|%s' % '&'.join(['%s=%s' % (key, quote_plus(headers[key])) for key in headers])     

    def get_packed_data(self,html):
        packed_data = ''
        try:
            for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
                r = match.group(1)
                t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
                if len(t) == 1:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
                else:
                    t = r.split('eval')
                    t = ['eval' + x for x in t if x]
                    for r in t:
                        if jsunpack.detect(r):
                            packed_data += jsunpack.unpack(r)
        except:
            pass
        return packed_data
    
    def todas_novelas(self,url=False):
        if not url:
            url = site_novelas
        itens = []
        next = False
        page = '' 
        try:
            parsed_url = urlparse(referer_novelas)
            protocol = parsed_url.scheme
            host = parsed_url.netloc
            referer = '%s://%s/'%(protocol,host)
            headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            n = soup.find('div', {'class': 'items normal'}).find_all('article', id=re.compile(r'^post'))
            if n:
                for i in n:
                    href = i.find('a').get('href', '')
                    name = i.find('div', {'class': 'title'}).find('h4').text
                    year = i.find('div', {'class': 'metadata'}).find('span').text
                    img = i.find('div', {'class': 'poster'}).find('img').get('src', '')
                    try:
                        name = name.decode('utf-8')
                    except:
                        pass
                    try:
                        year = year.decode('utf-8')
                    except:
                        pass
                    if year:
                        if not ')' in name:
                            name = name + ' (' + year + ')'
                        # else:
                        #     name = '[B]' + name + '[/B]'
                    # else:
                    #     name = '[B]' + name + '[/B]'
                    itens.append((name,href,img))
            try:
                pagination = soup.find('div', {'class': 'pagination'})
                current = pagination.find('span', {'class': 'current'}).text
                a_list = pagination.find_all('a')
                if a_list:
                    for i in a_list:
                        p = i.text
                        if int(current) < int(p) and int(p) + 1 == int(current) + 2:
                            next = i.get('href', '')
                            page = p
                            break
            except:
                pass

        except:
            pass
        return itens, next, page     


    # def todas_novelas2(self,url=False):
    #     if not url:
    #         url = site_novelas
    #     itens = []
    #     next = False
    #     page = ''
    #     try:
    #         # referer
    #         parsed_url = urlparse(referer_novelas)
    #         protocol = parsed_url.scheme
    #         host = parsed_url.netloc
    #         referer = '%s://%s/'%(protocol,host)
    #         headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
    #         r = requests.get(url,headers=headers)
    #         src = r.text
    #         soup = self.soup(src)
    #         n = soup.find('div', class_=re.compile(r'^filmlist')).find_all('div',id=re.compile(r'^post'))
    #         if n:
    #             for i in n:
    #                 href = i.find('a', {'class': 'poster'}).get('href', '')
    #                 name = i.find('h3').text
    #                 try:
    #                     year = i.find_all('span')[1].text
    #                 except:
    #                     year = ''
    #                 img = i.find('img').get('data-src', '')
    #                 try:
    #                     name = name.decode('utf-8')
    #                 except:
    #                     pass
    #                 try:
    #                     year = year.decode('utf-8')
    #                 except:
    #                     pass
    #                 if year:
    #                     if not ')' in name:
    #                         name = '[B]' + name + ' (' + year + ')[/B]'
    #                     else:
    #                         name = '[B]' + name + '[/B]'
    #                 else:
    #                     name = '[B]' + name + '[/B]'
    #                 itens.append((name,href,img))

    #         try:
    #             pagination = soup.find('div', {'class': 'pagenav'}).find('ul', {'class': 'pagination'})
    #             active = pagination.find('li', {'class': 'active'}).find('a')
    #             current_href = active.get('href', '')
    #             try:
    #                 last_li = pagination.find_all('li')[-1].find('a')
    #                 check = last_li.text
    #                 if check == 'Last':
    #                     last_href = last_li.get('href', '')
    #                     if not '/page/' in current_href:
    #                         next = current_href + 'page/2/'
    #                         page = '2'
    #                     else:
    #                         page_last = last_href.split('/page/')[1].split('/')[0]
    #                         page_current = current_href.split('/page/')[1].split('/')[0]
    #                         if int(page_current) < int(page_last):
    #                             page = str(int(page_current) + 1)
    #                             next = current_href.split('/page/')[0] + '/page/' + str(page) + '/'
    #             except:
    #                 pass
    #         except:
    #             pass
    #     except:
    #         pass
    #     return itens, next, page

    # def capitulos_backup(self,url):
    #     cap = []
    #     try:
    #         parsed_url = urlparse(referer_novelas)
    #         protocol = parsed_url.scheme
    #         host = parsed_url.netloc
    #         referer = '%s://%s/'%(protocol,host)
    #         headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
    #         # r = requests.get(url,headers=headers)
    #         # src = r.text
    #         r = requests2.get(url,headers=headers)
    #         src = r.text            
    #         last_url = r.url
    #         parsed_url = urlparse(last_url)
    #         protocol = parsed_url.scheme
    #         host = parsed_url.netloc
    #         referer = '%s://%s/'%(protocol,host)        
    #         soup = self.soup(src)
    #         li_tag = soup.find('li', {'id': 'player-option-1'})
    #         data_type = li_tag['data-type']
    #         data_post = li_tag['data-post']
    #         data_nume = li_tag['data-nume']
    #         headers.update({'Referer': url})           
    #         r = requests.post(referer + 'wp-admin/admin-ajax.php',headers=headers,data={'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type})
    #         try:
    #             html = r.json()
    #         except:
    #             html = {}
    #         embed_url = html.get('embed_url', '')
    #         if embed_url:
    #             soup = self.soup(embed_url)
    #             embed_url = soup.find('a').get('href', '')
    #         if embed_url:
    #             headers.update({'Referer': url})
    #             r = requests2.get(embed_url,headers=headers)
    #             src = r.text
    #             action = re.search(r'form.+?action="(.*?)"', src)
    #             if action:
    #                 action_url = action.group(1)
    #                 referer = action_url
    #                 input_fields = re.findall(r'input.+?name="(.*?)".+?value="(.*?)"',src)
    #                 form_data = {name: value for name, value in input_fields}
    #                 r = requests.post(action_url, data=form_data, headers=headers)
    #                 src = r.text
    #                 soup = self.soup(src)
    #                 iframe = soup.find('iframe').get('src', '')
    #                 headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
    #                 r = requests2.get(iframe,headers=headers,allow_redirects=True)
    #                 last_url = r.url
    #                 parsed_url = urlparse(last_url)
    #                 protocol = parsed_url.scheme
    #                 host = parsed_url.netloc
    #                 referer = '%s://%s/'%(protocol,host)                
    #                 src = r.text
    #                 soup = self.soup(src)
    #                 options = soup.find_all('option')
    #                 for option in options:
    #                     if option.has_attr('value') and option.text != u'SELECIONE UM CAPÍTULO AQUI':
    #                         link = option['value']
    #                         text = option.text
    #                         text = text[1:]
    #                         try:
    #                             text = text.decode('utf-8')
    #                         except:
    #                             pass
    #                         if 'cap' in text.lower():
    #                             text = '[B]' + text + '[/B]'
    #                             cap.append((text,link,referer))
    #     except:
    #         pass        
    #     return cap 
    # capitulos
    def capitulos(self,url):
        cap = [] 
        base_novela = url 
        try:
            try:
                parsed_url = urlparse(referer_novelas)
                protocol = parsed_url.scheme
                host = parsed_url.netloc
                referer = '%s://%s/'%(protocol,host)
                headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
                # r = requests.get(url,headers=headers)
                # src = r.text
                r = requests.get(url,headers=headers)
                src = r.text            
                last_url = r.url
                parsed_url = urlparse(last_url)
                protocol = parsed_url.scheme
                host = parsed_url.netloc
                referer = '%s://%s/'%(protocol,host)        
                soup = self.soup(src)
                li_tag = soup.find('li', {'id': 'player-option-1'})
                data_type = li_tag['data-type']
                data_post = li_tag['data-post']
                data_nume = li_tag['data-nume']
                headers.update({'Referer': url})           
                r = requests.post(referer + 'wp-admin/admin-ajax.php',headers=headers,data={'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type})
                try:
                    html = r.json()
                except:
                    html = {}
                embed_url = html.get('embed_url', '')
                if embed_url:
                    #     soup = self.soup(embed_url)
                    #     embed_url = soup.find('a').get('href', '')
                    # if embed_url:
                    #headers.update({'Referer': url})
                    r = requests.get(embed_url,headers=headers)
                    src = r.text
                    soup = self.soup(src)
                    c = soup.find_all('p', {'class': 'chapter-link'})
                    for i in c:
                        a = i.find('a')
                        link = a.get('href', '')
                        text = a.text
                        try:
                            text = text.decode('utf-8')
                        except:
                            pass                
                        #text = '[B]' + text + '[/B]'
                        cap.append((text,link,referer))
            except:
                pass
            try:
                if not cap:
                    # comecar denovo
                    url = base_novela
                    parsed_url = urlparse(referer_novelas)
                    protocol = parsed_url.scheme
                    host = parsed_url.netloc
                    referer = '%s://%s/'%(protocol,host)
                    headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
                    # r = requests.get(url,headers=headers)
                    # src = r.text
                    r = requests.get(url,headers=headers)
                    src = r.text            
                    last_url = r.url
                    parsed_url = urlparse(last_url)
                    protocol = parsed_url.scheme
                    host = parsed_url.netloc
                    referer = '%s://%s/'%(protocol,host)        
                    soup = self.soup(src) 
                    li_tag = soup.find('li', {'id': 'player-option-1'})
                    data_type = li_tag['data-type']
                    data_post = li_tag['data-post']
                    data_nume = li_tag['data-nume']
                    headers.update({'Referer': url})           
                    r = requests.post(referer + 'wp-admin/admin-ajax.php',headers=headers,data={'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type})
                    try:
                        html = r.json()
                    except:
                        html = {}
                    embed_url = html.get('embed_url', '')
                    if embed_url:
                        if not embed_url.startswith('http'):
                            soup = self.soup(embed_url)
                            embed_url = soup.find('a').get('href', '')
                    if embed_url:
                        headers.update({'Referer': url})
                        r = requests.get(embed_url,headers=headers)
                        src = r.text
                        action = re.search(r'form.+?action="(.*?)"', src)
                        if action:
                            action_url = action.group(1)
                            referer = action_url
                            input_fields = re.findall(r'input.+?name="(.*?)".+?value="(.*?)"',src)
                            form_data = {name: value for name, value in input_fields}
                            r = requests.post(action_url, data=form_data, headers=headers)
                            src = r.text
                            soup = self.soup(src)
                            iframe = soup.find('iframe').get('src', '')
                            headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
                            r = requests.get(iframe,headers=headers,allow_redirects=True)
                            last_url = r.url
                            parsed_url = urlparse(last_url)
                            protocol = parsed_url.scheme
                            host = parsed_url.netloc
                            referer = '%s://%s/'%(protocol,host)                
                            src = r.text
                            soup = self.soup(src)
                            options = soup.find_all('option')
                            for option in options:
                                if option.has_attr('value') and option.text != u'SELECIONE UM CAPÍTULO AQUI':
                                    link = option['value']
                                    text = option.text
                                    text = text[1:]
                                    try:
                                        text = text.decode('utf-8')
                                    except:
                                        pass
                                    if 'cap' in text.lower():
                                        #text = '[B]' + text + '[/B]'
                                        cap.append((text,link,referer))
            except:
                pass    
        except:
            pass
        return cap 


    # def capitulos2(self,url):
    #     cap = []
    #     try:
    #         parsed_url = urlparse(referer_novelas)
    #         protocol = parsed_url.scheme
    #         host = parsed_url.netloc
    #         referer = '%s://%s/'%(protocol,host)
    #         headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
    #         r = requests.get(url,headers=headers)
    #         src = r.text
    #         embed = re.findall(r"loadEmbed\('(.*?)'\);", src)[0]
    #         referer = embed
    #         if embed.count('http') > 1:                
    #             iframe = 'http' + embed.split('http')[2]
    #         else:
    #             iframe = embed
    #         headers.pop('Referer')
    #         r = requests2.get(iframe,headers=headers)
    #         src = r.text
    #         referer = iframe
    #         headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
    #         action = re.search(r'form.+?action="(.*?)"', src)
    #         if action:
    #             action_url = action.group(1)
    #             referer = action_url
    #             input_fields = re.findall(r'input.+?name="(.*?)".+?value="(.*?)"',src)
    #             form_data = {name: value for name, value in input_fields}
    #             r = requests.post(action_url, data=form_data, headers=headers)
    #             src = r.text
    #             soup = self.soup(src)
    #             iframe = soup.find('iframe').get('src', '')
    #             headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
    #             r = requests2.get(iframe,headers=headers,allow_redirects=True)
    #             last_url = r.url
    #             parsed_url = urlparse(last_url)
    #             protocol = parsed_url.scheme
    #             host = parsed_url.netloc
    #             referer = '%s://%s/'%(protocol,host)                
    #             src = r.text
    #             soup = self.soup(src)
    #             options = soup.find_all('option')
    #             for option in options:
    #                 if option.has_attr('value') and option.text != u'SELECIONE UM CAPÍTULO AQUI':
    #                     link = option['value']
    #                     text = option.text
    #                     text = text[1:]
    #                     try:
    #                         text = text.decode('utf-8')
    #                     except:
    #                         pass
    #                     if 'cap' in text.lower():
    #                         text = '[B]' + text + '[/B]'
    #                         cap.append((text,link,referer))     

    #     except:
    #         pass
    #     return cap
    # resolve novela
    def resolve_novela(self,url,referer):
        referer_player = url
        stream = ''
        # protecao
        try:
            headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
            r = requests.get(url,headers=headers)
            src = r.text
            action = re.search(r'form.+?action="(.*?)"', src)
            if action:
                action_url = action.group(1)
                referer = action_url
                input_fields = re.findall(r'input.+?name="(.*?)".+?value="(.*?)"',src)
                form_data = {name: value for name, value in input_fields}
                r = requests.post(action_url, data=form_data, headers=headers)
                src = r.text
                soup = self.soup(src)
                #
                iframe = soup.find('iframe').get('src', '')
                headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
                r = requests.get(iframe,headers=headers,allow_redirects=True)
                last_url = r.url
                parsed_url = urlparse(last_url)
                protocol = parsed_url.scheme
                host = parsed_url.netloc
                referer = '%s://%s/'%(protocol,host)                
                url = last_url
        except:
            pass
        # player                      
        try:
            headers.update({'Accept-Language': 'pt-BR', 'Referer': referer})
            r = requests.get(url,headers=headers)
            src = r.text
            headers.update({'Accept-Language': 'pt-BR', 'Referer': referer_player})
            new_src = self.get_packed_data(src)
            sources = re.findall(r'sources:(.*?),"image"', new_src)
            if sources:
                s = sources[0].replace("'", '"')
                s2 = json.loads(s)
                resolucao_maxima = -1
                url_maxima = ''
                for item in s2:
                    resolucao_str = item['label'][:-1]
                    resolucao = int(resolucao_str)
                    if resolucao > resolucao_maxima:
                        resolucao_maxima = resolucao
                        url_maxima = item['file']
                if url_maxima:
                    stream = url_maxima + self.append_headers(headers)        
        except:
            pass
        return stream        
         

# print(Doramas().opcoes_link('https://doramasonline.org/br/episodio/squid-game-temporada-2-episodio-1/'))