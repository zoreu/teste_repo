try:
    from kodi_six import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
except:
    try:
        import xbmcaddon, xbmcplugin, xbmc, xbmcgui, xbmcvfs
    except:
        pass
from urllib.parse import urlparse, parse_qs, quote_plus, quote
import base64
try:
    from lib import dns
except ImportError:
    import dns
try:
    from lib.dns import CloudflareHTTP
except:
    from dns import CloudflareHTTP

try:
    from lib import jsunpack
except:
    import jsunpack
from bs4 import BeautifulSoup
import re
import requests
import json

headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0'}

search_filmes_op1 = 'https://comandoplay.com/?s='
referer_filmes_op1 = 'https://comandoplay.com/'
site_filmes_op1 = 'https://comandoplay.com/category/movies-2/'
site_series_op1 = 'https://comandoplay.com/category/tv-series/'


class filmes_op1:
    def soup(self,src):
        soup = BeautifulSoup(src,'html.parser')
        return soup
    
    def get_packed_data(self,html):
        packed_data = ''
        try:
            for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
                r = match.group(1)
                t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
                if len(t) == 1:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
                else:
                    t = r.split('eval')
                    t = ['eval' + x for x in t if x]
                    for r in t:
                        if jsunpack.detect(r):
                            packed_data += jsunpack.unpack(r)
        except:
            pass
        return packed_data
    
    def pesquisa_conteudo(self,url=None,pesquisa=None):
        itens = []
        next = False
        page = ''
        if pesquisa:
            url = search_filmes_op1 + quote_plus(pesquisa)
        if url:
            try:
                headers.update({'Referer': referer_filmes_op1})
                r = requests.get(url,headers=headers)
                src = r.text
                soup = self.soup(src)
                container = soup.find('section', {'id': 'content'}).find('div', {'class': 'item-container'})
                posts = container.find_all("div", id=lambda x: x and x.startswith("post"))
                for i in posts:
                    img = i.find('img').get('data-src', '')
                    img = img.replace('w220_and_h330_face', 'w600_and_h900_bestv2')
                    name = i.find('h2', {'class': 'movie-title'}).text.strip()
                    try:
                        year = i.find('span', {'class': 'movie-date'}).text.strip()
                    except:
                        year = ''
                    try:
                        t = i.find('div', {'class': 'item-flip'}).find('span', {'class': 'item-tv'}).text
                        if t.lower() == 'tv':
                            t = 'tvshow'
                        else:
                            t = 'movie'
                    except:
                        t = 'movie'
                        
                    link = i.find('a').get('href', '')
                    try:
                        name = name.decode('utf-8')
                    except:
                        pass                    
                    if year:
                        name = name + ' (' + year + ')'
                    # set name to kodi
                    #name = '[B]' + name + '[/B]'
                    itens.append((name,link,img,t))
                try:
                    pagination = soup.find('div', {'class': 'pagination'})
                    current = soup.find('span', {'class': 'current'}).text.strip()
                    try:
                        next_ = pagination.find_all('a', {'class': 'next arrow_pag'})[-1].get('href', '')
                        if next_:
                            try:
                                page = next_.split('/page/')[1]
                            except:
                                page = ''
                            try:
                                page = page.split('/')[0]
                            except:
                                pass
                            try:
                                page = page.split('?')[0]
                            except:
                                pass
                            if int(page) > int(current):
                                next = next_
                    except:
                        try:
                            next_ = pagination.find_all('a', {'class': 'inactive'})[-1].get('href', '')
                            if next_:
                                try:
                                    page = next_.split('/page/')[1]
                                except:
                                    page = ''
                                try:
                                    page = page.split('/')[0]
                                except:
                                    pass
                            try:
                                page = page.split('?')[0]
                            except:
                                pass
                            p_base = page
                            if int(page) > int(current):
                                next = next_
                                p = int(page)
                                while True:                                
                                    if p > int(current):
                                        p = p - 1
                                    if p == int(current):
                                        p +=1
                                        break
                                next = next_.replace(p_base, str(p))
                                page = p
                        except:
                            pass

                except:
                    pass
            except:
                pass
        return itens, next, page  
            
    def catalogo_filmes(self,url=False):
        if not url:
            url = site_filmes_op1
        itens = []
        next = False
        page = ''
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            container = soup.find('section', {'id': 'content'}).find('div', {'class': 'item-container'})
            posts = container.find_all("div", id=lambda x: x and x.startswith("post"))
            for i in posts:
                img = i.find('img').get('data-src', '')
                img = img.replace('w220_and_h330_face', 'w600_and_h900_bestv2')
                name = i.find('h2', {'class': 'movie-title'}).text.strip()
                try:
                    year = i.find('span', {'class': 'movie-date'}).text.strip()
                except:
                    year = ''
                link = i.find('a').get('href', '')
                try:
                    name = name.decode('utf-8')
                except:
                    pass                    
                if year:
                    name = name + ' (' + year + ')'
                # set name to kodi
                #name = '[B]' + name + '[/B]'
                itens.append((name,link,img))
            try:
                pagination = soup.find('div', {'class': 'pagination'})
                current = soup.find('span', {'class': 'current'}).text.strip()
                try:
                    next_ = pagination.find_all('a', {'class': 'next arrow_pag'})[-1].get('href', '')
                    if next_:
                        try:
                            page = next_.split('/page/')[1]
                        except:
                            page = ''
                        try:
                            page = page.split('/')[0]
                        except:
                            pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        if int(page) > int(current):
                            next = next_
                except:
                    try:
                        next_ = pagination.find_all('a', {'class': 'inactive'})[-1].get('href', '')
                        if next_:
                            try:
                                page = next_.split('/page/')[1]
                            except:
                                page = ''
                            try:
                                page = page.split('/')[0]
                            except:
                                pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        p_base = page
                        if int(page) > int(current):
                            next = next_
                            p = int(page)
                            while True:                                
                                if p > int(current):
                                    p = p - 1
                                if p == int(current):
                                    p +=1
                                    break
                            next = next_.replace(p_base, str(p))
                            page = p
                    except:
                        pass

            except:
                pass
        except:
            pass
        return itens, next, page
    
    def catalogo_series(self,url=False):
        if not url:
            url = site_series_op1
        itens = []
        next = False
        page = ''
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            container = soup.find('section', {'id': 'content'}).find('div', {'class': 'item-container'})
            posts = container.find_all("div", id=lambda x: x and x.startswith("post"))
            for i in posts:
                img = i.find('img').get('data-src', '')
                img = img.replace('w220_and_h330_face', 'w600_and_h900_bestv2')
                name = i.find('h2', {'class': 'movie-title'}).text.strip()
                try:
                    year = i.find('span', {'class': 'movie-date'}).text.strip()
                except:
                    year = ''
                link = i.find('a').get('href', '')
                try:
                    name = name.decode('utf-8')
                except:
                    pass                    
                if year:
                    name = name + ' (' + year + ')'
                # set name to kodi
                #name = '[B]' + name + '[/B]'
                itens.append((name,link,img))
            try:
                pagination = soup.find('div', {'class': 'pagination'})
                current = soup.find('span', {'class': 'current'}).text.strip()
                try:
                    next_ = pagination.find_all('a', {'class': 'next arrow_pag'})[-1].get('href', '')
                    if next_:
                        try:
                            page = next_.split('/page/')[1]
                        except:
                            page = ''
                        try:
                            page = page.split('/')[0]
                        except:
                            pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        if int(page) > int(current):
                            next = next_
                except:
                    try:
                        next_ = pagination.find_all('a', {'class': 'inactive'})[-1].get('href', '')
                        if next_:
                            try:
                                page = next_.split('/page/')[1]
                            except:
                                page = ''
                            try:
                                page = page.split('/')[0]
                            except:
                                pass
                        try:
                            page = page.split('?')[0]
                        except:
                            pass
                        p_base = page
                        if int(page) > int(current):
                            next = next_
                            p = int(page)
                            while True:                                
                                if p > int(current):
                                    p = p - 1
                                if p == int(current):
                                    p +=1
                                    break
                            next = next_.replace(p_base, str(p))
                            page = p
                    except:
                        pass

            except:
                pass
        except:
            pass
        return itens, next, page    
    
    def temporadas(self,url):
        seasons = []
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            streaming = json.loads(re.findall(r'var streaming = (.*?);', src)[0])
            for i in streaming.keys():
                season = re.findall(r's(.*?)_', i)[0]
                if not season in seasons:
                    seasons.append((season))            
        except:
            pass
        return seasons 

    def episodios(self,season,url):
        itens = []
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            streaming = json.loads(re.findall(r'var streaming = (.*?);', src)[0])
            for i in streaming.keys():
                season_ = re.findall(r's(.*?)_', i)[0]
                episode_ = re.findall(r'_(.*)', i)[0]
                if season == season_:
                    link = streaming.get(i)
                    itens.append((episode_,link))          
        except:
            pass
        return itens            

    def opcoes_link(self,url):
        opcoes = []
        try:
            headers.update({'Referer': referer_filmes_op1})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            a = soup.find_all('a', {'rel': 'modal'})
            if a:
                n = 0
                for i in a:
                    link = i.get('href', '')
                    if 'br' in link or 'wish' in link or 'streamtape' in link:
                        n += 1
                        name = 'PLAYER %s'%str(n)
                        opcoes.append((name,link,url))

        except:
            pass
        return opcoes 

class filmes_op2:
    def __init__(self):
        self.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0'}        
        self.base = self.get_last_base()


    def get_last_base(self):
        host_base = 'https://netcine.mov'
        last_url = ''
        try:
            r = requests.get(host_base,headers=self.headers,timeout=4)
            last_url = r.url
        except:
            pass     

        if last_url and last_url.endswith('/'):
            last_url = last_url[:-1]
        return last_url

    def soup(self,src):
        soup = BeautifulSoup(src,'html.parser')
        return soup
    
    def get_packed_data(self,html):
        packed_data = ''
        try:
            for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
                r = match.group(1)
                t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
                if len(t) == 1:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
                else:
                    t = r.split('eval')
                    t = ['eval' + x for x in t if x]
                    for r in t:
                        if jsunpack.detect(r):
                            packed_data += jsunpack.unpack(r)
        except:
            pass
        return packed_data

    def pesquisa_filmes(self,url,pesquisa):
        itens_pesquisa = []
        next_page = False
        page = ''
        if pesquisa:
            url = '%s/?s=%s'%(self.base,quote_plus(pesquisa))           
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')
                if 'hdcam' in link and not 'hdcam' in name.lower():
                    name = '%s (HDCAM)'%name
                if year:
                    name = '%s (%s)'%(name,str(year))              
                itens_pesquisa.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return itens_pesquisa, next_page, page 

    def scraper_filmes(self, url=''):
        if not url:
            url = self.base + '/category/ultimos-filmes/'
        filmes = []
        next_page = False
        page = ''
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')                
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                if year:
                    if 'hdcam' in link and not 'hdcam' in name.lower():
                        name = '%s (%s) (HDCAM)'%(name,str(year))
                    else:
                        name = '%s (%s)'%(name,str(year))
                else:
                    if 'hdcam' in link and not 'hdcam' in name.lower():
                        name = '%s (HDCAM)'%name
                filmes.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return filmes, next_page, page

    def opcoes_filmes(self,url):
        opcoes = []      
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            player = soup.find('div', {'id': 'player-container'})
            botoes = player.find('ul', {'class': 'player-menu'})
            op = botoes.findAll('li')
            op_list = []
            if op:
                for i in op:
                    a = i.find('a')
                    id_ = a.get('href', '').replace('#', '')
                    op_name = a.text
                    try:
                        op_name = op_name.decode('utf-8')
                    except:
                        pass
                    op_name = op_name.replace(' 1', '').replace(' 2', '').replace(' 3', '').replace(' 4', '').replace(' 5', '')
                    op_name = op_name.strip()
                    op_name = op_name.upper()
                    op_list.append((op_name,id_))
            if op_list:
                for name, id_ in op_list:
                    iframe = player.find('div', {'class': 'play-c'}).find('div', {'id': id_}).find('iframe').get('src', '')
                    if not 'streamtape' in iframe:
                        link = self.base + '/' + iframe
                    else:
                        link = iframe
                    opcoes.append((name,link))

        except:
            pass
        return opcoes

    def scraper_series(self, url=''):
        if not url:
            url = self.base + '/tvshows/'          
        series = []
        next_page = False
        page = ''
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url,headers=headers_)
            src = r.text
            soup = self.soup(src)
            box = soup.find("div", {"id": "box_movies"})
            movies = box.findAll("div", {"class": "movie"})
            for i in movies:
                name = i.find('h2').text
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                try:
                    year = i.find('span', {'class': 'year'}).text
                    year = year.replace('–', '')
                except:
                    year = ''
                if year:
                    name = '%s (%s)'%(name,str(year))
                img = i.find('div', {'class': 'imagen'})
                iconimage = img.find('img').get('src', '')
                iconimage = iconimage.replace('-120x170', '')
                link = img.find('a').get('href', '')
                series.append((name,iconimage,link))
            try:
                div = soup.find('div', {'id': 'paginador'}).find('div', {'class': 'paginado'})
                current = div.find('span', {'class': 'current'}).text
                a = div.findAll('a')
                for i in a:
                    href = i.get('href', '')
                    nxt = str(int(current) + 1)
                    if nxt in href:
                        next_page = href
                        try:
                            page_ = next_page.split('page/')[1]
                            try:
                                page = page_.split('/')[0]
                            except:
                                page = page_
                        except:
                            pass
                        break

            except:
                pass
        except:
            pass
        return series, next_page, page

    def scraper_temporadas_series(self,url):
        url_original = url       
        list_seasons = []
        serie_name_final = ''
        img = ''
        fanart = ''        
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url, headers=headers_)
            src = r.text
            soup = self.soup(src)
            # info
            try:
                div_img = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'class': 'headingder'})
                fanart = div_img.find('div', class_=lambda x: x and 'lazyload' in x).get('data-bg', '')
                img = div_img.find('img', {'class': 'lazyload'}).get('data-src', '')
                try:
                    serie_name = div_img.find('div', {'class': 'datos'}).find('div', {'class': 'dataplus'}).find('h1').text
                    try:
                        serie_name = serie_name.decode('utf-8')
                    except:
                        pass
                    #serie_name_final = '[B]:::: SÉRIE: %s ::::[/B]'%serie_name
                    serie_name_final = serie_name
                except:
                    pass
            except:
                pass
            s = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'id': 'cssmenu'}).find('ul').findAll('li', {'class': 'has-sub'})
            for n, i in enumerate(s):
                n += 1
                name = 'TEMPORADA %s'%str(n)
                season = str(n)
                list_seasons.append((season,name,url_original))
        except:
            pass
        return serie_name_final, img, fanart, list_seasons 

    def scraper_episodios_series(self,url,season):
        list_episodes = []
        serie_name_final = ''
        img = ''
        fanart = ''        
        try:
            headers_ = self.headers
            headers_.update({'Cookie': 'XCRF%3DXCRF'})
            #headers.update({'Cookie': 'XCRF%3DXCRF'})
            r = requests.get(url, headers=headers_)
            src = r.text
            soup = self.soup(src)
            # info
            try:
                div_img = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'class': 'headingder'})
                fanart = div_img.find('div', class_=lambda x: x and 'lazyload' in x).get('data-bg', '')
                img = div_img.find('img', {'class': 'lazyload'}).get('data-src', '')
                try:
                    serie_name = div_img.find('div', {'class': 'datos'}).find('div', {'class': 'dataplus'}).find('h1').text
                    try:
                        serie_name = serie_name.decode('utf-8')
                    except:
                        pass
                    #serie_name_final = '[B]:::: SÉRIE: %s ::::[/B]'%serie_name
                    serie_name_final = serie_name
                except:
                    pass
            except:
                pass
            s = soup.find('div', {'id': 'movie'}).find('div', {'class': 'post'}).find('div', {'id': 'cssmenu'}).find('ul').findAll('li', {'class': 'has-sub'})
            for n, i in enumerate(s):
                n += 1
                if int(season) == n:
                    e = i.find('ul').findAll('li')
                    for n, i in enumerate(e):
                        n += 1
                        e_info = i.find('a')
                        link = e_info.get('href')
                        ep_name = e_info.find('span', {'class': 'datix'}).text
                        try:
                            ep_name = ep_name.decode('utf-8')
                        except:
                            pass
                        ep_name = ep_name.strip()
                        name_especial = '%s - %s x %s - %s'%(serie_name,str(season),str(n),ep_name)
                        ep_name2 = '%s - %s'%(str(n),ep_name)
                        list_episodes.append((ep_name2,name_especial,link))
                    break
        except:
            pass
        return serie_name_final, img, fanart, list_episodes         

filmes, next_page, page = filmes_op2().scraper_filmes(url='')
print(filmes)