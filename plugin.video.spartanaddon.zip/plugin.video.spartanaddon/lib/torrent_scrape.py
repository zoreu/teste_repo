# -*- coding: utf-8 -*-
try:
    from lib.dns import CloudflareHTTP
except:
    from dns import CloudflareHTTP
import json
try:
    from lib import github
except:
    import github


def get_list(url):
    list_items = []
    try:
        r = CloudflareHTTP.get(url, timeout=4, log=False)
        if r and 'response' in r:
            res = r['response']
            url = res.json()['url']
    except:
        pass
    try:
        if 'paste.kodi.tv' in url and not 'documents' in url and not 'raw' in url:
            try:
                key = url.split('/')[-1]
                url = 'https://paste.kodi.tv/documents/' + key
                r = CloudflareHTTP.get(url, timeout=4, log=False)
                if r and 'response' in r:
                    res = r['response']
                    src = res.json()['data']
                    list_items = json.loads(src)
            except:
                pass
        else:
            r = CloudflareHTTP.get(url, timeout=4, log=False)
            if r and 'response' in r:
                res = r['response']
                list_items = res.json()
    except:
        pass
    return list_items




# filmes = [
#     {"titulo": "Filme 1", "ano": 2022, "genero": "Ação"},
#     {"titulo": "Filme 2", "ano": 2021, "genero": "Drama"},
#     # Adicione mais dicionários de filmes conforme necessário...
# ]


def paginar_lista(lista, itens_por_pagina):
    # Calcula o número total de páginas
    num_paginas = len(lista) // itens_por_pagina + (1 if len(lista) % itens_por_pagina else 0)
    
    # Gera a lista paginada
    paginas = [lista[i * itens_por_pagina:(i + 1) * itens_por_pagina] for i in range(num_paginas)]
    return paginas, num_paginas

def pesquisar_filmes(url,search='',page=1, itens=1):
    filmes_ = []
    filmes_copia = []
    next_ = False
    url = github.last_gist(url)
    filmes = get_list(url)    
    if search:
        search = search.lower()
        if filmes:
            for i in filmes:
                key = i.get('key', '')
                key = key.lower()
                if search in key:
                    filmes_copia.append(i)
        itens_por_pagina = itens  # Defina quantos itens você quer por página
        paginas, total_paginas = paginar_lista(filmes_copia, itens_por_pagina)
        if page <= total_paginas:
            for filme in paginas[page-1]:
                filmes_.append(filme)
                if (page + 1) > total_paginas:
                    next_ = False
                else:
                    next_ = page + 1
    return filmes_, next_, total_paginas                  
        
        

def iterar_paginas(url, page=1, itens=1):
    filmes_ = []
    next_ = False
    url = github.last_gist(url)
    filmes = get_list(url)
    itens_por_pagina = itens  # Defina quantos itens você quer por página
    paginas, total_paginas = paginar_lista(filmes, itens_por_pagina)
    if page <= total_paginas:
        for filme in paginas[page-1]:
            filmes_.append(filme)
            if (page + 1) > total_paginas:
                next_ = False
            else:
                next_ = page + 1
    return filmes_, next_, total_paginas

# filmes, next, total = pesquisar_filmes('https://gist.github.com/zoreu/10c194c495d71741eb566d45d3f30b2f', search='forja', page=1, itens=1)
# print(filmes)

# filmes, next_ = iterar_paginas('https://gist.github.com/zoreu/10c194c495d71741eb566d45d3f30b2f', page=2, itens=2)
# print(filmes)




# Mostrando a primeira página
# for filme in paginas[1]:
#     print(f"{filme['titulo']} - {filme['ano']} - {filme['genero']}")
# url_filmes_lacamento = github.last_gist('https://gist.github.com/zoreu/10c194c495d71741eb566d45d3f30b2f')

# print(get_list(url_filmes_lacamento))
